import { Router } from 'express';
import { getProjects, getProjectById } from '../controllers/projectController.js';
import { authenticateToken } from '../middleware/authMiddleware.js';

const router = Router();

router.use(authenticateToken);

router.get('/', getProjects);
router.get('/:id', getProjectById);

export default router;
