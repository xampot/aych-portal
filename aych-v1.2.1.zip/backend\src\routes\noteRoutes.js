import { Router } from 'express';
import { getNotes, createNote, replyToNote, deleteNote, editNote } from '../controllers/noteController.js';
import { authenticateToken } from '../middleware/authMiddleware.js';
import { validateBody, validateQuery } from '../middleware/validateRequest.js';
import { createNoteSchema, replySchema, noteQuerySchema, editNoteSchema } from '../validators/noteValidator.js';

const router = Router();

router.use(authenticateToken);

router.get('/', validateQuery(noteQuerySchema), getNotes);
router.post('/', validateBody(createNoteSchema), createNote);
router.post('/:id/reply', validateBody(replySchema), replyToNote);
router.put('/:id', validateBody(editNoteSchema), editNote);
router.delete('/:id', deleteNote);

export default router;
