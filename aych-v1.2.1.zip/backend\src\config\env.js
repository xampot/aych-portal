import dotenv from 'dotenv';
import { z } from 'zod';

dotenv.config();

const envSchema = z.object({
  PORT: z.coerce.number().default(5000),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  JWT_SECRET: z.string().min(16).default('aych_portal_super_secure_jwt_secret_key_2026'),
  JWT_EXPIRES_IN: z.string().default('24h'),
  CORS_ORIGIN: z.string().default('http://localhost:5173'),
  DB_PATH: z.string().default('portal.db')
});

const parsedEnv = envSchema.safeParse(process.env);

if (!parsedEnv.success) {
  process.exit(1);
}

export const env = parsedEnv.data;
