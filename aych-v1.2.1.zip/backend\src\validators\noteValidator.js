import { z } from 'zod';

export const createNoteSchema = z.object({
  project_id: z.string().min(1, { message: 'Project ID is required' }),
  title: z.string().trim().min(1, { message: 'Title is required' }).max(200),
  body: z.string().trim().min(1, { message: 'Body is required' }).max(5000)
});

export const editNoteSchema = z.object({
  title: z.string().trim().min(1, { message: 'Title is required' }).max(200),
  body: z.string().trim().min(1, { message: 'Body is required' }).max(5000)
});

export const replySchema = z.object({
  body: z.string().trim().min(1, { message: 'Reply body is required' }).max(2000)
});

export const noteQuerySchema = z.object({
  project_id: z.string().min(1, { message: 'Project ID is required' })
});
