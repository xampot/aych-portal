import { db } from '../database/db.js';

export async function getNotifications(req, res, next) {
  try {
    const { projectId } = req.query;
    const companyId = req.company.id;
    const userId = req.user.id;

    let sql = `
      SELECT n.*, u.full_name AS actor_name, u.initials AS actor_initials, u.role AS actor_role
      FROM notifications n
      JOIN users u ON u.id = n.actor_id
      WHERE n.company_id = ? AND n.user_id = ?
    `;
    const params = [companyId, userId];

    if (projectId) {
      sql += ` AND n.project_id = ?`;
      params.push(projectId);
    }

    sql += ` ORDER BY n.created_at DESC LIMIT 50`;

    const notifications = db.all(sql, params);
    res.json({ success: true, data: notifications });
  } catch (err) {
    next(err);
  }
}

export async function getUnreadCount(req, res, next) {
  try {
    const companyId = req.company.id;
    const userId = req.user.id;
    const { projectId } = req.query;

    let sql = `SELECT COUNT(*) AS count FROM notifications WHERE company_id = ? AND user_id = ? AND is_read = 0`;
    const params = [companyId, userId];

    if (projectId) {
      sql += ` AND project_id = ?`;
      params.push(projectId);
    }

    const result = db.get(sql, params);
    res.json({ success: true, data: { count: result.count } });
  } catch (err) {
    next(err);
  }
}

export async function markAsRead(req, res, next) {
  try {
    const { id } = req.params;
    const companyId = req.company.id;
    const userId = req.user.id;

    db.run(
      `UPDATE notifications SET is_read = 1 WHERE id = ? AND company_id = ? AND user_id = ?`,
      [id, companyId, userId]
    );
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
}

export async function markAllAsRead(req, res, next) {
  try {
    const companyId = req.company.id;
    const userId = req.user.id;
    const { projectId } = req.body;

    let sql = `UPDATE notifications SET is_read = 1 WHERE company_id = ? AND user_id = ? AND is_read = 0`;
    const params = [companyId, userId];

    if (projectId) {
      sql += ` AND project_id = ?`;
      params.push(projectId);
    }

    db.run(sql, params);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
}

export async function deleteNotification(req, res, next) {
  try {
    const { id } = req.params;
    const companyId = req.company.id;
    const userId = req.user.id;

    db.run(
      `DELETE FROM notifications WHERE id = ? AND company_id = ? AND user_id = ?`,
      [id, companyId, userId]
    );
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
}

export function createNotification({ companyId, userId, actorId, type, referenceId, projectId, message }) {
  const id = crypto.randomUUID();
  db.run(
    `INSERT INTO notifications (id, company_id, user_id, actor_id, type, reference_id, project_id, message) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, companyId, userId, actorId, type, referenceId, projectId || null, message]
  );
  return id;
}
