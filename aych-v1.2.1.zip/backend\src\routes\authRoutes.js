import { Router } from 'express';
import { login, getCurrentUser, logout } from '../controllers/authController.js';
import { validateBody } from '../middleware/validateRequest.js';
import { loginSchema } from '../validators/authValidator.js';
import { authenticateToken } from '../middleware/authMiddleware.js';

const router = Router();

router.post('/login', validateBody(loginSchema), login);
router.get('/me', authenticateToken, getCurrentUser);
router.post('/logout', authenticateToken, logout);

export default router;
