import { db } from '../database/db.js';

export const getDashboardStats = async (req, res, next) => {
  try {
    const companyId = req.company.id;
    const { project_id } = req.query;

    let filesWhereClause = 'WHERE company_id = ?';
    const filesParams = [companyId];

    if (project_id) {
      filesWhereClause += ' AND project_id = ?';
      filesParams.push(project_id);
    }

    const totalFilesRow = db.get(
      `SELECT COUNT(*) AS total FROM files ${filesWhereClause}`,
      filesParams
    );

    const newThisWeekRow = db.get(
      `SELECT COUNT(*) AS total FROM files ${filesWhereClause} AND is_new = 1`,
      filesParams
    );

    let notesCount = 0;
    if (project_id) {
      const notesRow = db.get(
        'SELECT COUNT(*) AS total FROM notes WHERE project_id = ? AND company_id = ?',
        [project_id, companyId]
      );
      notesCount = notesRow ? notesRow.total : 0;
    }

    let foldersWhereClause = 'WHERE f.company_id = ?';
    const foldersParams = [companyId];

    if (project_id) {
      foldersWhereClause += ' AND fi.project_id = ?';
      foldersParams.push(project_id);
    }

    const folders = db.all(
      `SELECT 
        f.id, 
        f.slug, 
        f.name_en, 
        f.name_ar, 
        f.color, 
        f.icon, 
        COUNT(fi.id) AS file_count 
       FROM folders f 
       LEFT JOIN files fi ON f.id = fi.folder_id 
       ${foldersWhereClause}
       GROUP BY f.id, f.slug, f.name_en, f.name_ar, f.color, f.icon
       ORDER BY f.created_at ASC`,
      foldersParams
    );

    res.json({
      success: true,
      data: {
        company: req.company,
        totalFiles: totalFilesRow ? totalFilesRow.total : 0,
        newThisWeek: newThisWeekRow ? newThisWeekRow.total : 0,
        folders: folders.map((f) => ({
          id: f.id,
          slug: f.slug,
          nameEn: f.name_en,
          nameAr: f.name_ar,
          color: f.color,
          icon: f.icon,
          count: f.slug === 'notes' ? notesCount : f.file_count
        }))
      }
    });
  } catch (err) {
    next(err);
  }
};
