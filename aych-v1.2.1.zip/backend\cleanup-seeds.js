import { db } from './src/database/db.js';

const seedPatterns = [
  'Documents — Essider',
  'Notes — Essider',
  'Gallery — Essider',
  'Documents — Waha',
  'Notes — Waha',
  'Gallery — Waha',
  'Documents — Dahra',
  'Notes — Dahra',
  'Gallery — Dahra',
  'Documents — Gialo',
  'Notes — Gialo',
  'Gallery — Gialo',
  'Documents — Samah',
  'Notes — Samah',
  'Gallery — Samah'
];

for (const pattern of seedPatterns) {
  const files = db.all('SELECT id, name FROM files WHERE name LIKE ?', [`%${pattern}%`]);
  for (const file of files) {
    console.log(`Deleting seed file: ${file.name}`);
    db.run('DELETE FROM files WHERE id = ?', [file.id]);
  }
}

const remaining = db.get('SELECT COUNT(*) as count FROM files');
console.log(`\nRemaining files: ${remaining.count}`);
console.log('Seed cleanup complete.');
process.exit(0);
