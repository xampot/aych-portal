import { z } from 'zod';

export const fileQuerySchema = z.object({
  category: z.string().trim().optional(),
  search: z.string().trim().optional(),
  project_id: z.string().trim().optional(),
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().positive().max(100).default(50),
  sort: z.enum(['name', 'category', 'size_bytes', 'created_at']).default('created_at'),
  order: z.enum(['asc', 'desc']).default('desc')
});

export const fileIdParamSchema = z.object({
  id: z.string().min(1)
});

export const fileUploadSchema = z.object({
  name: z.string().trim().min(1, { message: 'File name is required' }).max(255),
  category: z.enum(['Documents', 'Gallery', 'Notes'], { message: 'category must be Documents, Gallery, or Notes' }),
  project_id: z.string().min(1, { message: 'Project ID is required' }),
  size_bytes: z.number().int().nonnegative().optional(),
  formatted_size: z.string().trim().optional(),
  mime_type: z.string().trim().optional()
});
