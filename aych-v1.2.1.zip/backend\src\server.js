import app from './app.js';
import { env } from './config/env.js';
import './database/db.js';
import './database/seed.js';

const server = app.listen(env.PORT, () => {
  process.stdout.write(`Server running on port ${env.PORT}\n`);
});

const gracefulShutdown = () => {
  server.close(() => {
    process.exit(0);
  });
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);
