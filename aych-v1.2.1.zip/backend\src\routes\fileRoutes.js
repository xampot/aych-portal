import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import crypto from 'node:crypto';
import { getFiles, getFileById, downloadFile, previewFile, uploadFile, deleteFile, bulkDeleteFiles } from '../controllers/fileController.js';
import { authenticateToken } from '../middleware/authMiddleware.js';
import { validateQuery, validateParams, validateBody } from '../middleware/validateRequest.js';
import { fileQuerySchema, fileIdParamSchema } from '../validators/fileValidator.js';

const router = Router();

router.use(authenticateToken);

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(process.cwd(), 'uploads'));
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.bin';
    cb(null, `${crypto.randomUUID()}${ext}`);
  }
});

const ALLOWED_MIMES = [
  'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml', 'image/bmp',
  'application/pdf',
  'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'text/plain', 'text/csv'
];

const fileFilter = (req, file, cb) => {
  if (ALLOWED_MIMES.includes(file.mimetype) || file.mimetype.startsWith('image/')) {
    cb(null, true);
  } else {
    cb(new Error(`Unsupported file type: ${file.mimetype}. Allowed: PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX, TXT, CSV, JPG, PNG, GIF, WEBP, SVG`));
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 50 * 1024 * 1024 }
});

router.get('/', validateQuery(fileQuerySchema), getFiles);
router.post('/', upload.array('files', 20), uploadFile);
router.delete('/bulk', bulkDeleteFiles);
router.delete('/:id', deleteFile);
router.get('/:id', validateParams(fileIdParamSchema), getFileById);
router.get('/:id/download', validateParams(fileIdParamSchema), downloadFile);
router.get('/:id/preview', validateParams(fileIdParamSchema), previewFile);

router.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ success: false, error: err.message });
  }
  if (err.message && err.message.startsWith('Unsupported file type')) {
    return res.status(400).json({ success: false, error: err.message });
  }
  next(err);
});

export default router;
