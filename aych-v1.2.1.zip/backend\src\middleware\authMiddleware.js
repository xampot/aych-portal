import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { db } from '../database/db.js';

export const authenticateToken = (req, res, next) => {
  let token = null;
  const authHeader = req.headers['authorization'];

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.substring(7);
  } else if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      error: 'Authentication required'
    });
  }

  try {
    const decoded = jwt.verify(token, env.JWT_SECRET);
    const user = db.get(
      'SELECT u.id, u.company_id, u.username, u.full_name, u.initials, u.role, c.name AS company_name, c.code AS company_code FROM users u JOIN companies c ON u.company_id = c.id WHERE u.id = ?',
      [decoded.userId]
    );

    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'User account not found or deactivated'
      });
    }

    req.user = {
      id: user.id,
      username: user.username,
      fullName: user.full_name,
      initials: user.initials,
      role: user.role,
      companyId: user.company_id
    };

    req.company = {
      id: user.company_id,
      name: user.company_name,
      code: user.company_code
    };

    next();
  } catch (err) {
    return res.status(401).json({
      success: false,
      error: 'Invalid or expired session token'
    });
  }
};
