import { db } from '../database/db.js';
import crypto from 'node:crypto';
import { createNotification } from './notificationController.js';

export const getNotes = async (req, res, next) => {
  try {
    const companyId = req.company.id;
    const { project_id } = req.query;

    if (!project_id) {
      return res.status(400).json({
        success: false,
        error: 'project_id is required'
      });
    }

    const notes = db.all(
      `SELECT n.id, n.title, n.body, n.created_at, n.updated_at,
              u.id AS user_id, u.full_name, u.initials, u.role
       FROM notes n
       JOIN users u ON n.user_id = u.id
       WHERE n.project_id = ? AND n.company_id = ?
       ORDER BY n.created_at DESC`,
      [project_id, companyId]
    );

    const notesWithReplies = notes.map((note) => {
      const replies = db.all(
        `SELECT r.id, r.body, r.created_at,
                u.id AS user_id, u.full_name, u.initials, u.role
         FROM note_replies r
         JOIN users u ON r.user_id = u.id
         WHERE r.note_id = ?
         ORDER BY r.created_at ASC`,
        [note.id]
      );

      return {
        id: note.id,
        title: note.title,
        body: note.body,
        createdAt: note.created_at,
        updatedAt: note.updated_at,
        user: {
          id: note.user_id,
          fullName: note.full_name,
          initials: note.initials,
          role: note.role
        },
        replies: replies.map((r) => ({
          id: r.id,
          body: r.body,
          createdAt: r.created_at,
          user: {
            id: r.user_id,
            fullName: r.full_name,
            initials: r.initials,
            role: r.role
          }
        }))
      };
    });

    res.json({
      success: true,
      data: notesWithReplies
    });
  } catch (err) {
    next(err);
  }
};

export const createNote = async (req, res, next) => {
  try {
    const companyId = req.company.id;
    const userId = req.user.id;
    const userRole = req.user.role;

    if (userRole !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Only admins can create notes'
      });
    }

    const { project_id, title, body } = req.body;

    if (!project_id || !title || !body) {
      return res.status(400).json({
        success: false,
        error: 'project_id, title, and body are required'
      });
    }

    const project = db.get(
      'SELECT id FROM projects WHERE id = ? AND company_id = ?',
      [project_id, companyId]
    );

    if (!project) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }

    const noteId = crypto.randomUUID();
    db.run(
      "INSERT INTO notes (id, project_id, company_id, user_id, title, body, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))",
      [noteId, project_id, companyId, userId, title, body]
    );

    const note = db.get(
      `SELECT n.id, n.title, n.body, n.created_at, n.updated_at,
              u.id AS user_id, u.full_name, u.initials, u.role
       FROM notes n
       JOIN users u ON n.user_id = u.id
       WHERE n.id = ?`,
      [noteId]
    );

    // Notify only admins about the new note
    const actorName = req.user.fullName || req.user.username;
    const adminUsers = db.all(
      'SELECT id FROM users WHERE company_id = ? AND role = ?',
      [companyId, 'admin']
    );
    for (const u of adminUsers) {
      const isActor = u.id === userId;
      createNotification({
        companyId,
        userId: u.id,
        actorId: userId,
        type: 'note_create',
        referenceId: project_id,
        projectId: project_id,
        message: isActor
          ? `You posted a note: "${title}"`
          : `${actorName} posted a note: "${title}"`
      });
    }

    res.status(201).json({
      success: true,
      data: {
        id: note.id,
        title: note.title,
        body: note.body,
        createdAt: note.created_at,
        updatedAt: note.updated_at,
        user: {
          id: note.user_id,
          fullName: note.full_name,
          initials: note.initials,
          role: note.role
        },
        replies: []
      }
    });
  } catch (err) {
    next(err);
  }
};

export const replyToNote = async (req, res, next) => {
  try {
    const companyId = req.company.id;
    const userId = req.user.id;
    const userRole = req.user.role;
    const { id } = req.params;
    const { body } = req.body;

    if (userRole !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Only admins can reply to notes'
      });
    }

    if (!body || !body.trim()) {
      return res.status(400).json({
        success: false,
        error: 'Reply body is required'
      });
    }

    const note = db.get(
      'SELECT id FROM notes WHERE id = ? AND company_id = ?',
      [id, companyId]
    );

    if (!note) {
      return res.status(404).json({
        success: false,
        error: 'Note not found'
      });
    }

    const replyId = crypto.randomUUID();
    db.run(
      "INSERT INTO note_replies (id, note_id, user_id, body, created_at) VALUES (?, ?, ?, ?, datetime('now'))",
      [replyId, id, userId, body.trim()]
    );

    const reply = db.get(
      `SELECT r.id, r.body, r.created_at,
              u.id AS user_id, u.full_name, u.initials, u.role
       FROM note_replies r
       JOIN users u ON r.user_id = u.id
       WHERE r.id = ?`,
      [replyId]
    );

    // Notify only admins about the reply
    const actorName = req.user.fullName || req.user.username;
    const adminUsers = db.all(
      'SELECT id FROM users WHERE company_id = ? AND role = ?',
      [companyId, 'admin']
    );
    for (const u of adminUsers) {
      const isActor = u.id === userId;
      createNotification({
        companyId,
        userId: u.id,
        actorId: userId,
        type: 'note_reply',
        referenceId: id,
        projectId: null,
        message: isActor
          ? `You replied to a note`
          : `${actorName} replied to a note`
      });
    }

    res.status(201).json({
      success: true,
      data: {
        id: reply.id,
        body: reply.body,
        createdAt: reply.created_at,
        user: {
          id: reply.user_id,
          fullName: reply.full_name,
          initials: reply.initials,
          role: reply.role
        }
      }
    });
  } catch (err) {
    next(err);
  }
};

export const deleteNote = async (req, res, next) => {
  try {
    const companyId = req.company.id;
    const userRole = req.user.role;
    const { id } = req.params;

    if (userRole !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Only admins can delete notes'
      });
    }

    const note = db.get(
      'SELECT id, title FROM notes WHERE id = ? AND company_id = ?',
      [id, companyId]
    );

    if (!note) {
      return res.status(404).json({
        success: false,
        error: 'Note not found'
      });
    }

    db.run('DELETE FROM note_replies WHERE note_id = ?', [id]);
    db.run('DELETE FROM notes WHERE id = ?', [id]);

    // Notify only admins about the deletion
    const actorName = req.user.fullName || req.user.username;
    const adminUsers = db.all(
      'SELECT id FROM users WHERE company_id = ? AND role = ?',
      [companyId, 'admin']
    );
    for (const u of adminUsers) {
      const isActor = u.id === req.user.id;
      createNotification({
        companyId,
        userId: u.id,
        actorId: req.user.id,
        type: 'note_delete',
        referenceId: null,
        projectId: null,
        message: isActor
          ? `You deleted note: "${note.title}"`
          : `${actorName} deleted note: "${note.title}"`
      });
    }

    res.json({
      success: true,
      message: 'Note deleted successfully'
    });
  } catch (err) {
    next(err);
  }
};

export const editNote = async (req, res, next) => {
  try {
    const companyId = req.company.id;
    const userRole = req.user.role;
    const { id } = req.params;
    const { title, body } = req.body;

    if (userRole !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Only admins can edit notes'
      });
    }

    if (!title || !body) {
      return res.status(400).json({
        success: false,
        error: 'Title and body are required'
      });
    }

    const note = db.get(
      'SELECT id FROM notes WHERE id = ? AND company_id = ?',
      [id, companyId]
    );

    if (!note) {
      return res.status(404).json({
        success: false,
        error: 'Note not found'
      });
    }

    db.run(
      "UPDATE notes SET title = ?, body = ?, updated_at = datetime('now') WHERE id = ?",
      [title, body, id]
    );

    const updatedNote = db.get(
      `SELECT n.id, n.title, n.body, n.created_at, n.updated_at,
              u.id AS user_id, u.full_name, u.initials, u.role
       FROM notes n
       JOIN users u ON n.user_id = u.id
       WHERE n.id = ?`,
      [id]
    );

    res.json({
      success: true,
      data: {
        id: updatedNote.id,
        title: updatedNote.title,
        body: updatedNote.body,
        createdAt: updatedNote.created_at,
        updatedAt: updatedNote.updated_at,
        user: {
          id: updatedNote.user_id,
          fullName: updatedNote.full_name,
          initials: updatedNote.initials,
          role: updatedNote.role
        }
      }
    });
  } catch (err) {
    next(err);
  }
};
