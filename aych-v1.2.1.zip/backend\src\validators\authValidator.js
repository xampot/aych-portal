import { z } from 'zod';

export const loginSchema = z.object({
  username: z.string().trim().min(3, { message: 'Username must be at least 3 characters' }).max(50),
  password: z.string().min(4, { message: 'Password must be at least 4 characters' })
});

export const tokenVerificationSchema = z.object({
  token: z.string().min(10)
});
