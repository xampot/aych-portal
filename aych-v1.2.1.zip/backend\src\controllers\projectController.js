import { db } from '../database/db.js';

export const getProjects = async (req, res, next) => {
  try {
    const companyId = req.company.id;

    const projects = db.all(
      'SELECT id, name, slug, created_at FROM projects WHERE company_id = ? ORDER BY created_at ASC',
      [companyId]
    );

    res.json({
      success: true,
      data: projects.map((p) => ({
        id: p.id,
        name: p.name,
        slug: p.slug,
        createdAt: p.created_at
      }))
    });
  } catch (err) {
    next(err);
  }
};

export const getProjectById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const companyId = req.company.id;

    const project = db.get(
      'SELECT id, name, slug, created_at FROM projects WHERE id = ? AND company_id = ?',
      [id, companyId]
    );

    if (!project) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }

    res.json({
      success: true,
      data: {
        id: project.id,
        name: project.name,
        slug: project.slug,
        createdAt: project.created_at
      }
    });
  } catch (err) {
    next(err);
  }
};
