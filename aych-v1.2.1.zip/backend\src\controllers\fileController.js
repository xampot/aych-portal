import { db } from '../database/db.js';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { createNotification } from './notificationController.js';

export const getFiles = async (req, res, next) => {
  try {
    const companyId = req.company.id;
    const { category, search, page, limit, sort, order, project_id } = req.query;

    let sql = 'SELECT id, folder_id, name, category, size_bytes, formatted_size, mime_type, file_url, is_new, created_at FROM files WHERE company_id = ?';
    let countSql = 'SELECT COUNT(*) AS total FROM files WHERE company_id = ?';
    const params = [companyId];
    const countParams = [companyId];

    if (project_id) {
      sql += ' AND project_id = ?';
      countSql += ' AND project_id = ?';
      params.push(project_id);
      countParams.push(project_id);
    }

    if (category && category !== 'All' && category !== 'الكل') {
      sql += ' AND LOWER(category) = LOWER(?)';
      countSql += ' AND LOWER(category) = LOWER(?)';
      params.push(category);
      countParams.push(category);
    }

    if (search && search.trim() !== '') {
      sql += ' AND LOWER(name) LIKE LOWER(?)';
      countSql += ' AND LOWER(name) LIKE LOWER(?)';
      const searchWildcard = `%${search.trim()}%`;
      params.push(searchWildcard);
      countParams.push(searchWildcard);
    }

    const sortColumn = ['name', 'category', 'size_bytes', 'created_at'].includes(sort) ? sort : 'created_at';
    const sortDirection = order && order.toLowerCase() === 'asc' ? 'ASC' : 'DESC';

    sql += ` ORDER BY ${sortColumn} ${sortDirection}`;

    const offset = (page - 1) * limit;
    sql += ' LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const files = db.all(sql, params);
    const countResult = db.get(countSql, countParams);
    const total = countResult ? countResult.total : 0;

    res.json({
      success: true,
      data: files.map((file) => ({
        id: file.id,
        folderId: file.folder_id,
        name: file.name,
        category: file.category,
        sizeBytes: file.size_bytes,
        formattedSize: file.formatted_size,
        mimeType: file.mime_type,
        fileUrl: file.file_url,
        isNew: Boolean(file.is_new),
        createdAt: file.created_at
      })),
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (err) {
    next(err);
  }
};

export const getFileById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const companyId = req.company.id;

    const file = db.get(
      'SELECT id, folder_id, name, category, size_bytes, formatted_size, mime_type, file_url, is_new, created_at FROM files WHERE id = ? AND company_id = ?',
      [id, companyId]
    );

    if (!file) {
      return res.status(404).json({
        success: false,
        error: 'File not found'
      });
    }

    res.json({
      success: true,
      data: {
        id: file.id,
        folderId: file.folder_id,
        name: file.name,
        category: file.category,
        sizeBytes: file.size_bytes,
        formattedSize: file.formatted_size,
        mimeType: file.mime_type,
        fileUrl: file.file_url,
        isNew: Boolean(file.is_new),
        createdAt: file.created_at
      }
    });
  } catch (err) {
    next(err);
  }
};

export const downloadFile = async (req, res, next) => {
  try {
    const { id } = req.params;
    const companyId = req.company.id;

    const file = db.get(
      'SELECT id, name, mime_type, formatted_size, file_url FROM files WHERE id = ? AND company_id = ?',
      [id, companyId]
    );

    if (!file) {
      return res.status(404).json({
        success: false,
        error: 'File not found'
      });
    }

    if (file.file_url && file.file_url.startsWith('/uploads/')) {
      const filePath = path.join(process.cwd(), file.file_url);
      if (fs.existsSync(filePath)) {
        const ext = path.extname(file.name) || path.extname(filePath);
        res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(file.name)}"`);
        res.setHeader('Content-Type', file.mime_type || 'application/octet-stream');
        return res.sendFile(filePath);
      }
    }

    const fileContent = `Aych Portal Secure Document Storage\nDocument: ${file.name}\nMIME: ${file.mime_type}\nSize: ${file.formatted_size}\nAuthenticated Company: ${req.company.name}\nVerification Code: ${file.id}`;
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(file.name)}"`);
    res.setHeader('Content-Type', file.mime_type || 'application/octet-stream');
    res.send(fileContent);
  } catch (err) {
    next(err);
  }
};

export const previewFile = async (req, res, next) => {
  try {
    const { id } = req.params;
    const companyId = req.company.id;

    const file = db.get(
      'SELECT id, name, mime_type, formatted_size, category FROM files WHERE id = ? AND company_id = ?',
      [id, companyId]
    );

    if (!file) {
      return res.status(404).json({
        success: false,
        error: 'File not found'
      });
    }

    res.json({
      success: true,
      data: {
        id: file.id,
        name: file.name,
        category: file.category,
        mimeType: file.mime_type,
        size: file.formatted_size,
        previewUrl: `/api/files/${file.id}/download`,
        company: req.company.name
      }
    });
  } catch (err) {
    next(err);
  }
};

function formatFileSize(bytes) {
  if (bytes === 0) return '0 KB';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

function detectCategory(mimetype, originalName) {
  if (mimetype && mimetype.startsWith('image/')) return 'Gallery';
  const ext = (originalName || '').split('.').pop().toLowerCase();
  const imageExts = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'ico'];
  if (imageExts.includes(ext)) return 'Gallery';
  return 'Documents';
}

export const uploadFile = async (req, res, next) => {
  try {
    const companyId = req.company.id;
    const userRole = req.user.role;

    if (userRole !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Only admins can upload files'
      });
    }

    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'No files provided'
      });
    }

    const project_id = req.body.project_id;
    if (!project_id) {
      return res.status(400).json({
        success: false,
        error: 'project_id is required'
      });
    }

    const project = db.get(
      'SELECT id FROM projects WHERE id = ? AND company_id = ?',
      [project_id, companyId]
    );
    if (!project) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }

    const uploadedFiles = [];

    for (const file of req.files) {
      const category = detectCategory(file.mimetype, file.originalname);
      const name = req.body.name || file.originalname;
      const folder = db.get(
        'SELECT id FROM folders WHERE LOWER(name_en) = LOWER(?) AND company_id = ?',
        [category, companyId]
      );

      const fileId = crypto.randomUUID();
      const finalSizeBytes = file.size;
      const finalFormattedSize = formatFileSize(file.size);
      const finalMimeType = file.mimetype || 'application/octet-stream';
      const fileUrl = `/uploads/${file.filename}`;

      db.run(
        `INSERT INTO files (id, company_id, folder_id, project_id, name, category, size_bytes, formatted_size, mime_type, file_url, is_new, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, datetime('now'), datetime('now'))`,
        [
          fileId,
          companyId,
          folder ? folder.id : null,
          project_id,
          name,
          category,
          finalSizeBytes,
          finalFormattedSize,
          finalMimeType,
          fileUrl
        ]
      );

      const inserted = db.get('SELECT * FROM files WHERE id = ?', [fileId]);
      uploadedFiles.push({
        id: inserted.id,
        folderId: inserted.folder_id,
        name: inserted.name,
        category: inserted.category,
        sizeBytes: inserted.size_bytes,
        formattedSize: inserted.formatted_size,
        mimeType: inserted.mime_type,
        fileUrl: inserted.file_url,
        isNew: Boolean(inserted.is_new),
        createdAt: inserted.created_at
      });
    }

    // Notify all users in the company about the upload
    const actorName = req.user.fullName || req.user.username;
    const fileCount = uploadedFiles.length;
    const fileLabel = fileCount === 1 ? uploadedFiles[0].name : `${fileCount} files`;
    const companyUsers = db.all(
      'SELECT id FROM users WHERE company_id = ?',
      [companyId]
    );
    for (const u of companyUsers) {
      const isActor = u.id === req.user.id;
      createNotification({
        companyId,
        userId: u.id,
        actorId: req.user.id,
        type: 'file_upload',
        referenceId: project_id,
        projectId: project_id,
        message: isActor
          ? `You uploaded ${fileLabel}`
          : `${actorName} uploaded ${fileLabel}`
      });
    }

    res.status(201).json({
      success: true,
      data: uploadedFiles
    });
  } catch (err) {
    next(err);
  }
};

export const deleteFile = async (req, res, next) => {
  try {
    const { id } = req.params;
    const companyId = req.company.id;
    const userRole = req.user.role;

    if (userRole !== 'admin') {
      return res.status(403).json({ success: false, error: 'Only admins can delete files' });
    }

    const file = db.get(
      'SELECT id, name, file_url, project_id FROM files WHERE id = ? AND company_id = ?',
      [id, companyId]
    );

    if (!file) {
      return res.status(404).json({ success: false, error: 'File not found' });
    }

    if (file.file_url && file.file_url.startsWith('/uploads/')) {
      const filePath = path.join(process.cwd(), file.file_url);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }

    db.run('DELETE FROM files WHERE id = ? AND company_id = ?', [id, companyId]);

    // Notify only admins about the deletion
    const actorName = req.user.fullName || req.user.username;
    const adminUsers = db.all(
      'SELECT id FROM users WHERE company_id = ? AND role = ?',
      [companyId, 'admin']
    );
    for (const u of adminUsers) {
      const isActor = u.id === req.user.id;
      createNotification({
        companyId,
        userId: u.id,
        actorId: req.user.id,
        type: 'file_delete',
        referenceId: file.project_id,
        projectId: file.project_id,
        message: isActor
          ? `You deleted "${file.name}"`
          : `${actorName} deleted "${file.name}"`
      });
    }

    res.json({ success: true, message: 'File deleted' });
  } catch (err) {
    next(err);
  }
};

export const bulkDeleteFiles = async (req, res, next) => {
  try {
    const companyId = req.company.id;
    const userRole = req.user.role;

    if (userRole !== 'admin') {
      return res.status(403).json({ success: false, error: 'Only admins can delete files' });
    }

    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ success: false, error: 'ids array is required' });
    }

    const placeholders = ids.map(() => '?').join(',');
    const files = db.all(
      `SELECT id, file_url FROM files WHERE id IN (${placeholders}) AND company_id = ?`,
      [...ids, companyId]
    );

    for (const file of files) {
      if (file.file_url && file.file_url.startsWith('/uploads/')) {
        const filePath = path.join(process.cwd(), file.file_url);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }
      }
    }

    db.run(
      `DELETE FROM files WHERE id IN (${placeholders}) AND company_id = ?`,
      [...ids, companyId]
    );

    // Notify only admins about the bulk deletion
    const actorName = req.user.fullName || req.user.username;
    const adminUsers = db.all(
      'SELECT id FROM users WHERE company_id = ? AND role = ?',
      [companyId, 'admin']
    );
    for (const u of adminUsers) {
      const isActor = u.id === req.user.id;
      createNotification({
        companyId,
        userId: u.id,
        actorId: req.user.id,
        type: 'file_delete',
        referenceId: null,
        projectId: null,
        message: isActor
          ? `You deleted ${files.length} files`
          : `${actorName} deleted ${files.length} files`
      });
    }

    res.json({ success: true, message: `${files.length} files deleted` });
  } catch (err) {
    next(err);
  }
};
