import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { db } from './db.js';

const existingCompany = db.get('SELECT id FROM companies LIMIT 1');
if (existingCompany) {
  // Database already seeded, skip
} else {

const companyId = crypto.randomUUID();
db.run(
  "INSERT INTO companies (id, name, code, created_at, updated_at) VALUES (?, ?, ?, datetime('now'), datetime('now'))",
  [companyId, 'Waha Oil Company', 'WAHA']
);

const salt = bcrypt.genSaltSync(10);
const passwordHash = bcrypt.hashSync('password123', salt);

// Regular user
const userId = crypto.randomUUID();
db.run(
  "INSERT INTO users (id, company_id, username, password_hash, full_name, initials, role, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))",
  [userId, companyId, 'wahaoil', passwordHash, 'Waha Oil Company', 'WO', 'user']
);

// Admin user
const adminId = crypto.randomUUID();
const adminHash = bcrypt.hashSync('admin123', salt);
db.run(
  "INSERT INTO users (id, company_id, username, password_hash, full_name, initials, role, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))",
  [adminId, companyId, 'admin', adminHash, 'System Administrator', 'SA', 'admin']
);

// Create 5 projects
const projectConfigs = [
  { name: 'EsSider', slug: 'essider' },
  { name: 'Waha', slug: 'waha' },
  { name: 'Dahra', slug: 'dahra' },
  { name: 'Gialo', slug: 'gialo' },
  { name: 'Samah', slug: 'samah' }
];

const projectIds = {};

for (const p of projectConfigs) {
  const projectId = crypto.randomUUID();
  projectIds[p.slug] = projectId;
  db.run(
    "INSERT INTO projects (id, company_id, name, slug, created_at, updated_at) VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
    [projectId, companyId, p.name, p.slug]
  );
}

const folderConfigs = [
  { slug: 'documents', name_en: 'Documents', name_ar: 'المستندات', color: 'blue', icon: 'file-text', count: 21 },
  { slug: 'gallery', name_en: 'Gallery', name_ar: 'المعرض', color: 'amber', icon: 'image', count: 41 },
  { slug: 'notes', name_en: 'Notes', name_ar: 'الملاحظات', color: 'teal', icon: 'sticky-note', count: 28 }
];

const folderIds = {};

for (const f of folderConfigs) {
  const folderId = crypto.randomUUID();
  folderIds[f.slug] = folderId;
  db.run(
    "INSERT INTO folders (id, company_id, slug, name_en, name_ar, color, icon, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))",
    [folderId, companyId, f.slug, f.name_en, f.name_ar, f.color, f.icon]
  );
}

// Distribute files across ALL 5 projects
const allProjectSlugs = ['essider', 'waha', 'dahra', 'gialo', 'samah'];

const primaryFiles = [
  {
    name: 'Annual Services Agreement 2026',
    category: 'Documents',
    folder_slug: 'documents',
    size_bytes: 2516582,
    formatted_size: '2.4 MB',
    mime_type: 'application/pdf',
    file_url: '/files/annual-services-agreement-2026.pdf',
    is_new: 1,
    created_at: '2026-08-28 10:15:00'
  },
  {
    name: 'August Invoice — #4471',
    category: 'Notes',
    folder_slug: 'notes',
    size_bytes: 188416,
    formatted_size: '184 KB',
    mime_type: 'application/pdf',
    file_url: '/files/august-invoice-4471.pdf',
    is_new: 1,
    created_at: '2026-08-27 14:20:00'
  },
  {
    name: 'Q3 Financial Report',
    category: 'Documents',
    folder_slug: 'documents',
    size_bytes: 1153433,
    formatted_size: '1.1 MB',
    mime_type: 'application/pdf',
    file_url: '/files/q3-financial-report.pdf',
    is_new: 0,
    created_at: '2026-08-25 09:45:00'
  },
  {
    name: 'Business License Scan',
    category: 'Gallery',
    folder_slug: 'gallery',
    size_bytes: 3879731,
    formatted_size: '3.7 MB',
    mime_type: 'image/png',
    file_url: '/files/business-license-scan.png',
    is_new: 0,
    created_at: '2026-08-22 16:30:00'
  },
  {
    name: 'July Invoice — #4390',
    category: 'Notes',
    folder_slug: 'notes',
    size_bytes: 180224,
    formatted_size: '176 KB',
    mime_type: 'application/pdf',
    file_url: '/files/july-invoice-4390.pdf',
    is_new: 0,
    created_at: '2026-07-31 11:10:00'
  },
  {
    name: 'Site Inspection Photos',
    category: 'Gallery',
    folder_slug: 'gallery',
    size_bytes: 8598323,
    formatted_size: '8.2 MB',
    mime_type: 'application/zip',
    file_url: '/files/site-inspection-photos.zip',
    is_new: 0,
    created_at: '2026-07-28 13:00:00'
  },
  {
    name: 'Supply Contract Draft',
    category: 'Documents',
    folder_slug: 'documents',
    size_bytes: 552960,
    formatted_size: '540 KB',
    mime_type: 'application/pdf',
    file_url: '/files/supply-contract-draft.pdf',
    is_new: 0,
    created_at: '2026-07-20 08:30:00'
  }
];

for (const item of primaryFiles) {
  db.run(
    'INSERT INTO files (id, company_id, folder_id, project_id, name, category, size_bytes, formatted_size, mime_type, file_url, is_new, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    [
      crypto.randomUUID(),
      companyId,
      folderIds[item.folder_slug],
      projectIds['waha'],
      item.name,
      item.category,
      item.size_bytes,
      item.formatted_size,
      item.mime_type,
      item.file_url,
      item.is_new,
      item.created_at,
      item.created_at
    ]
  );
}

// Generate files for each project (3 Documents, 3 Gallery, 3 Notes per project)
for (const slug of allProjectSlugs) {
  const pid = projectIds[slug];
  let fileIndex = 0;

  for (const f of folderConfigs) {
    for (let i = 1; i <= 3; i++) {
      fileIndex++;
      const sizeMb = ((fileIndex * 137) % 800) + 120;
      const sizeFormatted = sizeMb > 1000 ? `${(sizeMb / 1024).toFixed(1)} MB` : `${sizeMb} KB`;
      const fileName = `${f.name_en} — ${slug.charAt(0).toUpperCase() + slug.slice(1)} #${100 + i}`;
      const isNew = (f.slug === 'documents' || f.slug === 'notes') && i === 1 ? 1 : 0;
      const createdDate = isNew ? '2026-07-15 10:00:00' : '2026-05-10 10:00:00';

      db.run(
        'INSERT INTO files (id, company_id, folder_id, project_id, name, category, size_bytes, formatted_size, mime_type, file_url, is_new, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
          crypto.randomUUID(),
          companyId,
          folderIds[f.slug],
          pid,
          fileName,
          f.name_en,
          sizeMb * 1024,
          sizeFormatted,
          'application/pdf',
          `/files/${f.slug}-${slug}-${i}.pdf`,
          isNew,
          createdDate,
          createdDate
        ]
      );
    }
  }

  // 1 sample note per project (created by admin)
  const noteId = crypto.randomUUID();
  db.run(
    "INSERT INTO notes (id, project_id, company_id, user_id, title, body, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))",
    [
      noteId,
      pid,
      companyId,
      adminId,
      `Welcome to ${projectConfigs.find(p => p.slug === slug).name}`,
      `This is a sample status update for the ${projectConfigs.find(p => p.slug === slug).name} project. All team members can view this note.`
    ]
  );
}
}
