import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { db } from '../database/db.js';
import { env } from '../config/env.js';

export const login = async (req, res, next) => {
  try {
    const { username, password } = req.body;

    const user = db.get(
      'SELECT u.id, u.company_id, u.username, u.password_hash, u.full_name, u.initials, u.role, c.name AS company_name, c.code AS company_code FROM users u JOIN companies c ON u.company_id = c.id WHERE LOWER(u.username) = LOWER(?)',
      [username]
    );

    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'Invalid username or password'
      });
    }

    const isMatch = bcrypt.compareSync(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        error: 'Invalid username or password'
      });
    }

    const token = jwt.sign(
      {
        userId: user.id,
        companyId: user.company_id,
        username: user.username,
        role: user.role
      },
      env.JWT_SECRET,
      { expiresIn: env.JWT_EXPIRES_IN }
    );

    res.cookie('token', token, {
      httpOnly: true,
      secure: env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 24 * 60 * 60 * 1000
    });

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        username: user.username,
        fullName: user.full_name,
        initials: user.initials,
        role: user.role
      },
      company: {
        id: user.company_id,
        name: user.company_name,
        code: user.company_code
      }
    });
  } catch (err) {
    next(err);
  }
};

export const getCurrentUser = async (req, res, next) => {
  try {
    res.json({
      success: true,
      user: req.user,
      company: req.company
    });
  } catch (err) {
    next(err);
  }
};

export const logout = async (req, res, next) => {
  try {
    res.clearCookie('token');
    res.json({
      success: true,
      message: 'Logged out successfully'
    });
  } catch (err) {
    next(err);
  }
};
