import { env } from '../config/env.js';

export const sendChatEmail = async ({ senderName, senderUsername, message, projectName, adminEmail }) => {
  if (!env.RESEND_API_KEY || !adminEmail) {
    console.warn('[Email] Resend not configured — email not sent');
    return;
  }

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${env.RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: 'Aych Portal <onboarding@resend.dev>',
        to: [adminEmail],
        subject: `New chat message from ${senderName} [${projectName || 'General'}]`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: #2563eb; color: white; padding: 16px 20px; border-radius: 8px 8px 0 0;">
              <h2 style="margin: 0; font-size: 16px;">Aych Portal - New Chat Message</h2>
            </div>
            <div style="background: #f9fafb; padding: 20px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
              <p style="margin: 0 0 4px; color: #6b7280; font-size: 13px;"><strong>${senderName}</strong> (@${senderUsername})</p>
              ${projectName ? `<p style="margin: 0 0 8px; font-size: 12px; color: #2563eb; background: #eff6ff; display: inline-block; padding: 2px 8px; border-radius: 4px;">${projectName}</p>` : ''}
              <div style="background: white; padding: 14px; border-radius: 8px; border: 1px solid #e5e7eb; margin-top: 8px;">
                <p style="margin: 0; font-size: 14px; line-height: 1.5; color: #111827;">${message}</p>
              </div>
              <p style="margin: 16px 0 0; color: #9ca3af; font-size: 12px;">Log in to Aych Portal to reply.</p>
            </div>
          </div>
        `
      })
    });

    const result = await response.json();
    if (!response.ok) {
      console.error('[Email] Resend error:', result);
      return;
    }
    console.log(`[Email] Sent chat notification to ${adminEmail} (id: ${result.id})`);
  } catch (err) {
    console.error('[Email] Failed to send:', err.message);
  }
};
