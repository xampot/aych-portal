import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { env } from '../config/env.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbFilePath = path.isAbsolute(env.DB_PATH)
  ? env.DB_PATH
  : path.join(__dirname, '..', '..', env.DB_PATH);

const database = new DatabaseSync(dbFilePath);

database.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS companies (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    initials TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'member',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS user_sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS folders (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    slug TEXT NOT NULL,
    name_en TEXT NOT NULL,
    name_ar TEXT NOT NULL,
    color TEXT NOT NULL,
    icon TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    slug TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    folder_id TEXT REFERENCES folders(id) ON DELETE SET NULL,
    project_id TEXT REFERENCES projects(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    formatted_size TEXT NOT NULL,
    mime_type TEXT NOT NULL DEFAULT 'application/pdf',
    file_url TEXT NOT NULL,
    is_new INTEGER NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_users_company ON users(company_id);
  CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
  CREATE INDEX IF NOT EXISTS idx_folders_company ON folders(company_id);
  CREATE INDEX IF NOT EXISTS idx_folders_slug ON folders(slug);
  CREATE INDEX IF NOT EXISTS idx_projects_company ON projects(company_id);
  CREATE INDEX IF NOT EXISTS idx_projects_slug ON projects(slug);
  CREATE INDEX IF NOT EXISTS idx_files_company ON files(company_id);
  CREATE INDEX IF NOT EXISTS idx_files_folder ON files(folder_id);
  CREATE INDEX IF NOT EXISTS idx_files_category ON files(category);
  CREATE INDEX IF NOT EXISTS idx_files_created ON files(created_at);

  CREATE TABLE IF NOT EXISTS notes (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS note_replies (
    id TEXT PRIMARY KEY,
    note_id TEXT NOT NULL REFERENCES notes(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    body TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_notes_project ON notes(project_id);
  CREATE INDEX IF NOT EXISTS idx_notes_company ON notes(company_id);
  CREATE INDEX IF NOT EXISTS idx_notes_user ON notes(user_id);
  CREATE INDEX IF NOT EXISTS idx_note_replies_note ON note_replies(note_id);
  CREATE INDEX IF NOT EXISTS idx_note_replies_user ON note_replies(user_id);

  CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    actor_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    reference_id TEXT,
    project_id TEXT REFERENCES projects(id) ON DELETE SET NULL,
    message TEXT NOT NULL,
    is_read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_notifications_company ON notifications(company_id);
  CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
  CREATE INDEX IF NOT EXISTS idx_notifications_project ON notifications(project_id);
  CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(is_read);
  CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at);

  CREATE TABLE IF NOT EXISTS chat_messages (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    sender_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    is_read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_chat_company ON chat_messages(company_id);
  CREATE INDEX IF NOT EXISTS idx_chat_sender ON chat_messages(sender_id);
  CREATE INDEX IF NOT EXISTS idx_chat_created ON chat_messages(created_at);
  CREATE INDEX IF NOT EXISTS idx_chat_read ON chat_messages(is_read);
`);

// Migration: Add project_id to files if it doesn't exist (for existing databases)
try {
  const columns = database.prepare("PRAGMA table_info(files)").all();
  const hasProjectId = columns.some(col => col.name === 'project_id');
  if (!hasProjectId) {
    database.exec("ALTER TABLE files ADD COLUMN project_id TEXT REFERENCES projects(id) ON DELETE SET NULL");
    console.log('Migration: Added project_id column to files table');
  }
} catch (err) {
  // Column might already exist, ignore
}

// Create index on project_id after migration (safe for new and existing databases)
try {
  database.exec("CREATE INDEX IF NOT EXISTS idx_files_project ON files(project_id)");
} catch (err) {
  // Ignore if index already exists
}

// Migration: Add project_id to notifications if it doesn't exist (for existing databases)
try {
  const columns = database.prepare("PRAGMA table_info(notifications)").all();
  const hasProjectId = columns.some(col => col.name === 'project_id');
  if (!hasProjectId) {
    database.exec("ALTER TABLE notifications ADD COLUMN project_id TEXT REFERENCES projects(id) ON DELETE SET NULL");
    console.log('Migration: Added project_id column to notifications table');
  }
} catch (err) {
  // Column might already exist, ignore
}

try {
  database.exec("CREATE INDEX IF NOT EXISTS idx_notifications_project ON notifications(project_id)");
} catch (err) {
  // Ignore if index already exists
}

// Migration: Add project_id to chat_messages if it doesn't exist (for existing databases)
try {
  const columns = database.prepare("PRAGMA table_info(chat_messages)").all();
  const hasProjectId = columns.some(col => col.name === 'project_id');
  if (!hasProjectId) {
    database.exec("ALTER TABLE chat_messages ADD COLUMN project_id TEXT REFERENCES projects(id) ON DELETE SET NULL");
    console.log('Migration: Added project_id column to chat_messages table');
  }
} catch (err) {
  // Column might already exist, ignore
}

try {
  database.exec("CREATE INDEX IF NOT EXISTS idx_chat_project ON chat_messages(project_id)");
} catch (err) {
  // Ignore if index already exists
}

export const db = {
  all(sql, params = []) {
    const stmt = database.prepare(sql);
    return stmt.all(...params);
  },
  get(sql, params = []) {
    const stmt = database.prepare(sql);
    return stmt.get(...params);
  },
  run(sql, params = []) {
    const stmt = database.prepare(sql);
    return stmt.run(...params);
  },
  exec(sql) {
    return database.exec(sql);
  }
};
