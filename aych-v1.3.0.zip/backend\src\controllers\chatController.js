import crypto from 'node:crypto';
import { db } from '../database/db.js';
import { env } from '../config/env.js';
import { sendChatEmail } from '../services/emailService.js';

export const sendMessage = async (req, res, next) => {
  try {
    const { message, project_id } = req.body;
    const companyId = req.user.companyId;
    const senderId = req.user.id;

    if (!message || !message.trim()) {
      return res.status(400).json({ success: false, error: 'Message is required' });
    }

    const id = crypto.randomUUID();
    db.run(
      'INSERT INTO chat_messages (id, company_id, sender_id, message, project_id) VALUES (?, ?, ?, ?, ?)',
      [id, companyId, senderId, message.trim(), project_id || null]
    );

    const msg = db.get(
      `SELECT cm.*, u.full_name AS sender_name, u.initials AS sender_initials, u.role AS sender_role,
              p.name AS project_name
       FROM chat_messages cm
       JOIN users u ON cm.sender_id = u.id
       LEFT JOIN projects p ON cm.project_id = p.id
       WHERE cm.id = ?`,
      [id]
    );

    if (env.ADMIN_EMAIL && env.SMTP_USER) {
      sendChatEmail({
        senderName: req.user.fullName,
        senderUsername: req.user.username,
        message: message.trim(),
        projectName: msg.project_name || 'General',
        adminEmail: env.ADMIN_EMAIL
      }).catch(() => {});
    }

    res.status(201).json({ success: true, data: msg });
  } catch (err) {
    next(err);
  }
};

export const getMessages = async (req, res, next) => {
  try {
    const companyId = req.user.companyId;
    const { before, limit = 50 } = req.query;

    let sql = `SELECT cm.*, u.full_name AS sender_name, u.initials AS sender_initials, u.role AS sender_role,
                      p.name AS project_name
               FROM chat_messages cm
               JOIN users u ON cm.sender_id = u.id
               LEFT JOIN projects p ON cm.project_id = p.id
               WHERE cm.company_id = ?`;
    const params = [companyId];

    if (before) {
      sql += ' AND cm.created_at < ?';
      params.push(before);
    }

    sql += ' ORDER BY cm.created_at DESC LIMIT ?';
    params.push(Number(limit));

    const messages = db.all(sql, params);

    res.json({ success: true, data: messages.reverse() });
  } catch (err) {
    next(err);
  }
};

export const getUnreadCount = async (req, res, next) => {
  try {
    const companyId = req.user.companyId;
    const userId = req.user.id;

    const result = db.get(
      'SELECT COUNT(*) AS count FROM chat_messages WHERE company_id = ? AND is_read = 0 AND sender_id != ?',
      [companyId, userId]
    );

    res.json({ success: true, data: { count: result.count } });
  } catch (err) {
    next(err);
  }
};

export const markAsRead = async (req, res, next) => {
  try {
    const companyId = req.user.companyId;
    const userId = req.user.id;

    db.run(
      'UPDATE chat_messages SET is_read = 1 WHERE company_id = ? AND is_read = 0 AND sender_id != ?',
      [companyId, userId]
    );

    res.json({ success: true, message: 'Messages marked as read' });
  } catch (err) {
    next(err);
  }
};
