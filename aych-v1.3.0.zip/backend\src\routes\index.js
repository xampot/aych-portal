import { Router } from 'express';
import authRoutes from './authRoutes.js';
import dashboardRoutes from './dashboardRoutes.js';
import fileRoutes from './fileRoutes.js';
import projectRoutes from './projectRoutes.js';
import noteRoutes from './noteRoutes.js';
import notificationRoutes from './notificationRoutes.js';
import chatRoutes from './chatRoutes.js';

const apiRouter = Router();

apiRouter.use('/auth', authRoutes);
apiRouter.use('/dashboard', dashboardRoutes);
apiRouter.use('/files', fileRoutes);
apiRouter.use('/projects', projectRoutes);
apiRouter.use('/notes', noteRoutes);
apiRouter.use('/notifications', notificationRoutes);
apiRouter.use('/chat', chatRoutes);

export default apiRouter;
