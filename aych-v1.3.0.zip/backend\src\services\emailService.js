import tls from 'node:tls';
import { env } from '../config/env.js';

function smtpSend({ host, port, user, pass, from, to, subject, html }) {
  return new Promise((resolve, reject) => {
    let buffer = '';
    let step = 0;

    const socket = tls.connect(port, host, { rejectUnauthorized: true }, () => {
      // Connection ready, wait for banner
    });

    const processLine = (line) => {
      console.log(`[SMTP] S: ${line.substring(0, 100)}`);

      if (step === 0) {
        // Banner received
        socket.write('EHLO localhost\r\n');
        step = 1;
        return;
      }

      if (step === 1) {
        // EHLO response — wait for final 250 without dash
        if (line.startsWith('250 ') || line === '250') {
          socket.write('AUTH LOGIN\r\n');
          step = 2;
        }
        return;
      }

      if (step === 2 && line.startsWith('334')) {
        socket.write(Buffer.from(user).toString('base64') + '\r\n');
        step = 3;
        return;
      }

      if (step === 3 && line.startsWith('334')) {
        socket.write(Buffer.from(pass).toString('base64') + '\r\n');
        step = 4;
        return;
      }

      if (step === 4 && line.startsWith('235')) {
        socket.write(`MAIL FROM:<${from}>\r\n`);
        step = 5;
        return;
      }

      if (step === 5 && line.startsWith('250')) {
        socket.write(`RCPT TO:<${to}>\r\n`);
        step = 6;
        return;
      }

      if (step === 6 && line.startsWith('250')) {
        socket.write('DATA\r\n');
        step = 7;
        return;
      }

      if (step === 7 && line.startsWith('354')) {
        const body = [
          `From: Aych Portal <${from}>`,
          `To: <${to}>`,
          `Subject: ${subject}`,
          'MIME-Version: 1.0',
          'Content-Type: text/html; charset=UTF-8',
          '',
          html,
          '.\r\n'
        ].join('\r\n');
        socket.write(body);
        step = 8;
        return;
      }

      if (step === 8 && line.startsWith('250')) {
        socket.write('QUIT\r\n');
        step = 9;
        return;
      }

      if (step === 9 || line.startsWith('221')) {
        socket.destroy();
        resolve();
      }
    };

    socket.on('data', (chunk) => {
      buffer += chunk.toString();
      const lines = buffer.split('\r\n');
      buffer = lines.pop();
      for (const line of lines) {
        if (line.trim()) processLine(line.trim());
      }
    });

    socket.setTimeout(10000);
    socket.on('timeout', () => { socket.destroy(); reject(new Error('SMTP timeout')); });
    socket.on('error', (e) => { socket.destroy(); reject(e); });
  });
}

export const sendChatEmail = async ({ senderName, senderUsername, message, projectName, adminEmail }) => {
  if (!env.SMTP_HOST || !env.SMTP_USER || !env.SMTP_PASS || !adminEmail) {
    console.warn('[Email] SMTP not configured — email not sent');
    return;
  }

  try {
    await smtpSend({
      host: env.SMTP_HOST,
      port: env.SMTP_PORT,
      user: env.SMTP_USER,
      pass: env.SMTP_PASS,
      from: env.SMTP_USER,
      to: adminEmail,
      subject: `New chat message from ${senderName} [${projectName || 'General'}]`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: #2563eb; color: white; padding: 16px 20px; border-radius: 8px 8px 0 0;">
            <h2 style="margin: 0; font-size: 16px;">Aych Portal - New Chat Message</h2>
          </div>
          <div style="background: #f9fafb; padding: 20px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
            <p style="margin: 0 0 4px; color: #6b7280; font-size: 13px;"><strong>${senderName}</strong> (@${senderUsername})</p>
            ${projectName ? `<p style="margin: 0 0 8px; font-size: 12px; color: #2563eb; background: #eff6ff; display: inline-block; padding: 2px 8px; border-radius: 4px;">${projectName}</p>` : ''}
            <div style="background: white; padding: 14px; border-radius: 8px; border: 1px solid #e5e7eb; margin-top: 8px;">
              <p style="margin: 0; font-size: 14px; line-height: 1.5; color: #111827;">${message}</p>
            </div>
            <p style="margin: 16px 0 0; color: #9ca3af; font-size: 12px;">Log in to Aych Portal to reply.</p>
          </div>
        </div>
      `
    });
    console.log(`[Email] Sent chat notification to ${adminEmail}`);
  } catch (err) {
    console.error('[Email] Failed to send:', err.message);
  }
};
