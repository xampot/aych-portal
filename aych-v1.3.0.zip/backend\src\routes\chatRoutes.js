import { Router } from 'express';
import { authenticateToken } from '../middleware/authMiddleware.js';
import { sendMessage, getMessages, getUnreadCount, markAsRead } from '../controllers/chatController.js';

const chatRoutes = Router();

chatRoutes.use(authenticateToken);
chatRoutes.post('/send', sendMessage);
chatRoutes.get('/messages', getMessages);
chatRoutes.get('/unread-count', getUnreadCount);
chatRoutes.patch('/read', markAsRead);

export default chatRoutes;
