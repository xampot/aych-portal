import React from 'react';
import { Files, Sparkles } from 'lucide-react';

export const StatCard = ({ type, count, label }) => {
  const isFiles = type === 'totalFiles';

  return (
    <div className="stat-card">
      <div className={`stat-icon-wrapper ${isFiles ? 'stat-icon-teal' : 'stat-icon-peach'}`}>
        {isFiles ? <Files size={22} className="stat-icon" /> : <Sparkles size={22} className="stat-icon" />}
      </div>
      <div className="stat-content">
        <span className="stat-value">{count}</span>
        <span className="stat-label">{label}</span>
      </div>
    </div>
  );
};
