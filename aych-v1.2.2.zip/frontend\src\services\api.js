const BASE_URL = '/api';

export const api = {
  async login(username, password) {
    const response = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Authentication failed');
    }
    return result;
  },

  async getCurrentUser(token) {
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/auth/me`, {
      method: 'GET',
      headers
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to fetch user');
    }
    return result;
  },

  async logout(token) {
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/auth/logout`, {
      method: 'POST',
      headers
    });
    return response.json();
  },

  async getProjects(token) {
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/projects`, {
      method: 'GET',
      headers
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to fetch projects');
    }
    return result;
  },

  async getDashboardStats(token, projectId) {
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const params = new URLSearchParams();
    if (projectId) {
      params.append('project_id', projectId);
    }
    const queryString = params.toString();
    const url = `${BASE_URL}/dashboard/stats${queryString ? `?${queryString}` : ''}`;
    const response = await fetch(url, {
      method: 'GET',
      headers
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to fetch dashboard stats');
    }
    return result.data;
  },

  async getFiles({ token, category, search, page = 1, limit = 50, projectId }) {
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const params = new URLSearchParams();
    if (projectId) {
      params.append('project_id', projectId);
    }
    if (category && category !== 'All' && category !== 'الكل') {
      params.append('category', category);
    }
    if (search && search.trim() !== '') {
      params.append('search', search.trim());
    }
    params.append('page', page);
    params.append('limit', limit);

    const response = await fetch(`${BASE_URL}/files?${params.toString()}`, {
      method: 'GET',
      headers
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to fetch files');
    }
    return result;
  },

  async uploadFile(token, { files, projectId }) {
    const formData = new FormData();
    for (const f of files) {
      formData.append('files', f.file);
    }
    formData.append('project_id', projectId);

    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/files`, {
      method: 'POST',
      headers,
      body: formData
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to upload files');
    }
    return result.data;
  },

  async getFilePreview(id, token) {
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/files/${id}/preview`, {
      method: 'GET',
      headers
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to fetch file preview');
    }
    return result.data;
  },

  async downloadFile(id, fileName, token) {
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/files/${id}/download`, {
      method: 'GET',
      headers
    });
    if (!response.ok) {
      throw new Error('Failed to download file');
    }
    const blob = await response.blob();
    const disposition = response.headers.get('Content-Disposition') || '';
    const match = disposition.match(/filename\*?=(?:UTF-8'')?["']?([^"';\n]+)/i);
    const downloadName = match
      ? decodeURIComponent(match[1].replace(/"/g, ''))
      : (fileName || 'document');
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = downloadName;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  },

  async getNotes(token, projectId) {
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/notes?project_id=${projectId}`, {
      method: 'GET',
      headers
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to fetch notes');
    }
    return result.data;
  },

  async createNote(token, { projectId, title, body }) {
    const headers = {
      'Content-Type': 'application/json'
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/notes`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ project_id: projectId, title, body })
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to create note');
    }
    return result.data;
  },

  async replyToNote(token, noteId, body) {
    const headers = {
      'Content-Type': 'application/json'
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/notes/${noteId}/reply`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ body })
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to reply to note');
    }
    return result.data;
  },

  async deleteNote(token, noteId) {
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/notes/${noteId}`, {
      method: 'DELETE',
      headers
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to delete note');
    }
    return result;
  },

  async editNote(token, noteId, { title, body }) {
    const headers = {
      'Content-Type': 'application/json'
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/notes/${noteId}`, {
      method: 'PUT',
      headers,
      body: JSON.stringify({ title, body })
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to update note');
    }
    return result.data;
  },

  async deleteFile(token, fileId) {
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/files/${fileId}`, {
      method: 'DELETE',
      headers
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to delete file');
    }
    return result;
  },

  async bulkDeleteFiles(token, ids) {
    const headers = {
      'Content-Type': 'application/json'
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/files/bulk`, {
      method: 'DELETE',
      headers,
      body: JSON.stringify({ ids })
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to delete files');
    }
    return result;
  },

  async getNotifications(token, projectId) {
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const params = projectId ? `?projectId=${projectId}` : '';
    const response = await fetch(`${BASE_URL}/notifications${params}`, {
      method: 'GET',
      headers
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to fetch notifications');
    }
    return result.data;
  },

  async getUnreadCount(token, projectId) {
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const params = projectId ? `?projectId=${projectId}` : '';
    const response = await fetch(`${BASE_URL}/notifications/unread-count${params}`, {
      method: 'GET',
      headers
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to fetch unread count');
    }
    return result.data.count;
  },

  async markNotificationRead(token, id) {
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/notifications/${id}/read`, {
      method: 'PATCH',
      headers
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to mark as read');
    }
    return result;
  },

  async markAllNotificationsRead(token, projectId) {
    const headers = {
      'Content-Type': 'application/json'
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${BASE_URL}/notifications/read-all`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify({ projectId })
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to mark all as read');
    }
    return result;
  }
};
