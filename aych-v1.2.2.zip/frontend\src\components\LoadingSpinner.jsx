import React from 'react';
import { Loader2 } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.jsx';

export const LoadingSpinner = ({ label }) => {
  const { t } = useLanguage();

  return (
    <div className="loading-spinner-container">
      <Loader2 size={36} className="spinner-icon" />
      <span className="spinner-label">{label || t('loadingData')}</span>
    </div>
  );
};
