# Aych Document Portal

بوابة إدارة المستندات الرقمية (Document Management Portal) — تطبيق ويب متكامل (Full-stack) لعرض واستعراض مستندات شركة بتسجيل دخول آمن، ولوحة تحكم تعرض الإحصائيات والمجلدات، مع دعم كامل للغتين العربية والإنجليزية (RTL/LTR).

> **ملاحظة تقنية:** المشروع يتكوّن من جزأين منفصلين: **backend** (Node.js + Express + SQLite) و **frontend** (React + Vite).

---

## 1. الفكرة (What it does)

يوفر هذا التطبيق بوابة آمنة لموظفي/مستخدمي الشركة لتصفّح مستنداتها:

- **تسجيل دخول آمن** عبر JWT مُخزّن في Cookie (httpOnly) ورأس `Authorization`.
- **لوحة تحكم** (Dashboard) تعرض:
  - إجمالي الملفات.
  - عدد الملفات الجديدة هذا الأسبوع.
  - بطاقات المجلدات (العقود، الفواتير، التقارير، الصور) مع عدد الملفات في كل مجلد.
- **استعراض الملفات** في جدول قابل للتصفية حسب الفئة والبحث بالاسم، مع دعم تقسيم صفحات (Pagination) وترتيب (Sorting).
- **معاينة وتنزيل** الملفات، وحفظ شارة "جديد" (New) على المستندات الحديثة.
- **دعم ثنائي اللغة** (عربي/إنجليزي) مع تبديل فوري كامل، بما في ذلك اتجاه الصفحة (RTL/LTR).

---

## 2. التقنيات المستخدمة (Tech Stack)

| الطبقة | التقنيات |
|--------|-----------|
| **Backend** | Node.js, Express 4, SQLite (`node:sqlite`), JWT (`jsonwebtoken`), bcryptjs, Zod, dotenv, cors, helmet, cookie-parser |
| **Frontend** | React 18, Vite 5, lucide-react, Context API, Hooks مخصصة |
| **الملفات** | JavaScript ES Modules (`"type": "module"`) |

> **متطلّب**: Node.js **22+** (لأن الخلفية تستخدم الوحدة المدمجة `node:sqlite`، المتوفرة رسمياً ابتداءً من Node 22).

---

## 3. هيكل المشروع (Project Structure)

```
aych-document-portal/
├── package.json              # سكربتات موحّدة للإدارة
├── backend/
│   ├── .env.example          # نموذج متغيرات البيئة
│   ├── portal.db             # قاعدة بيانات SQLite (تُنشأ تلقائياً)
│   └── src/
│       ├── server.js         # نقطة الدخول + إيقاف تشغيل سلس
│       ├── app.js            # إعداد Express (cors, helmet, etc.)
│       ├── config/env.js     # قراءة/تحقّق متغيرات البيئة عبر Zod
│       ├── database/
│       │   ├── db.js         # اتصال SQLite + إنشاء الجداول + فهارس
│       │   ├── seed.js       # بيانات تجريبية (شركة، مستخدم، مجلدات، ملفات)
│       │   └── schema.sql    # مخطط SQL (مرجعي)
│       ├── routes/           # طبقة التوجيه (URL → Controller)
│       │   ├── index.js
│       │   ├── authRoutes.js
│       │   ├── dashboardRoutes.js
│       │   └── fileRoutes.js
│       ├── controllers/      # منطق العمل (Business Logic)
│       │   ├── authController.js
│       │   ├── dashboardController.js
│       │   └── fileController.js
│       ├── middleware/       # وسائط (Middleware)
│       │   ├── authMiddleware.js   # تحقق JWT + تحميل المستخدم/الشركة
│       │   ├── validateRequest.js  # تحقق body/query/params عبر Zod
│       │   └── errorHandler.js     # 404 + معالج أخطاء عام
│       └── validators/       # مخططات Zod
│           ├── authValidator.js
│           └── fileValidator.js
└── frontend/
    ├── index.html
    ├── vite.config.js        # إعداد Vite + بروكسي /api → backend
    └── src/
        ├── main.jsx          # نقطة دخول React
        ├── App.jsx           # مزوّدات السياق + التشغيل (Login/Dashboard)
        ├── pages/
        │   ├── LoginPage.jsx
        │   └── DashboardPage.jsx
        ├── components/       # مكوّنات واجهة قابلة لإعادة الاستخدام
        │   ├── Navbar.jsx
        │   ├── StatCard.jsx
        │   ├── FolderCard.jsx
        │   ├── FilesTable.jsx
        │   ├── FilePreviewModal.jsx
        │   ├── LanguageToggle.jsx
        │   ├── LoadingSpinner.jsx
        │   └── EmptyState.jsx
        ├── hooks/            # منطق جلب البيانات
        │   ├── useFiles.js
        │   └── useDashboard.js
        ├── context/          # حالة عامة (Auth + لغة)
        │   ├── AuthContext.jsx
        │   └── LanguageContext.jsx
        ├── services/api.js   # طبقة الاتصال بالخادم (fetch)
        ├── translations/     # ملفات الترجمة
        │   ├── en.js
        │   └── ar.js
        ├── styles/           # أنماط CSS
        │   ├── index.css
        │   ├── login.css
        │   └── dashboard.css
        └── assets/logo.png
```

---

## 4. المعمارية (Architecture)

### 4.1 Backend — نمط MVC مع طبقات

```
المتطلب (Request)
     │
     ▼
  app.js  (Express, cors, helmet, json/cookie-parser)
     │
     ▼
 routes/  (توجيه URL + ربط middleware و controllers)
     │  │
     │  └── middleware/  (authMiddleware, validateRequest)
     ▼
 controllers/  (منطق العمل: استعلامات DB + بناء الاستجابة)
     │
     ▼
 database/db.js  (SQLite) ──► portal.db
```

- **config/env.js**: يقرأ `process.env` ويتحقّق منه عبر مخطط **Zod**، مع قيم افتراضية آمنة. إذا فشل التحقق ينهي العملية.
- **middleware/validateRequest.js**: يدعم تحقّق `body` و `query` و `params` دفعة واحدة، ويُعيد استجابة `400` مع تفاصيل الأخطاء عند الفشل.
- **middleware/authMiddleware.js**: يستخرج الـ token من رأس `Authorization: Bearer ...` أو من الـ cookie، يتحقق منه، ويحمّل بيانات المستخدم والشركة إلى `req.user` / `req.company` — وهما متاحان لكل الـ controllers المحمية.
- **controllers/**: تقوم بجلب البيانات من قاعدة البيانات وتجهيز الاستجابة. لاحظ أن التنزيل (`downloadFile`) يُعيد نصاً وصفياً (metadata) بدلاً من ملف حقيقي — انظر "قيود معروفة".

### 4.2 Frontend — بنية مكوّناتية مع Context

```
main.jsx  (ReactDOM.render)
   │
   ▼
App.jsx
   ├── LanguageProvider  (اللغة + t + isRtl)
   │   └── AuthProvider  (token + user + company + login/logout)
   │       └── AppContent
   │           ├── (غير محمّلة) → LoadingSpinner
   │           ├── (محمّلة وغير مصادق) → LoginPage
   │           └── (محمّلة ومصادق) → DashboardPage
```

- **context/LanguageContext.jsx**: يحفظ اللغة في `localStorage`، ويعيّن اتجاه الصفحة `dir` و `lang` على `<html>`. يوفّر دالة `t(key)` للترجمة، و `isRtl`.
- **context/AuthContext.jsx**: يتولّى حفظ الـ token والمستخدم والشركة في `localStorage`، ويراقب صحة الجلسة عند التحميل، ويوفّر `login` و `logout`.
- **hooks/**: `useFiles` و `useDashboard` يغلفان جلب البيانات مع إدارة حالات التحميل والخطأ والتصفية/البحث.
- **services/api.js**: جميع طلبات `fetch` في مكان واحد (login, me, logout, stats, files, preview, download).
- **translations/**: قواميس `en`/`ar`؛ عند تغيير اللغة يُعاد حساب كل نص عبر `t()`، بما فيها رسائل الحالة (مثل "تم تسجيل الخروج").

### 4.3 تدفّق المصادقة (Auth Flow)

1. يسجّل المستخدم الدخول → `POST /api/auth/login` → يتحقق `bcrypt`، ويُصدر `JWT`، ويُخزّنه في cookie (httpOnly) ويُرجعه في الاستجابة.
2. تحفظ الواجهة الـ token في `localStorage` لإعادة استخدامه في رأس الطلبات.
3. كل طلبات اللوحة تُرسل الـ token → `authMiddleware` يتحقق منه ويحمّل `req.company`.
4. عند تسجيل الخروج → `POST /api/auth/logout` → تُمسح الجلسة محلياً ويُعاد الانتقال لصفحة الدخول.

---

## 5. نموذج البيانات (Data Model)

| الجدول | الأعمدة الأساسية |
|--------|------------------|
| `companies` | `id`, `name`, `code`, `created_at`, `updated_at` |
| `users` | `id`, `company_id` (FK), `username`, `password_hash`, `full_name`, `initials`, `role`, `created_at`, `updated_at` |
| `user_sessions` | `id`, `user_id` (FK), `token_hash`, `expires_at`, `created_at` |
| `folders` | `id`, `company_id` (FK), `slug`, `name_en`, `name_ar`, `color`, `icon`, `created_at` |
| `files` | `id`, `company_id` (FK), `folder_id` (FK), `name`, `category`, `size_bytes`, `formatted_size`, `mime_type`, `file_url`, `is_new`, `created_at`, `updated_at` |

وتُضاف فهارس (Indexes) على أعمدة الشركة والمجلد والفئة واسم المستخدم لتحسين الأداء.

---

## 6. واجهات API (Endpoints)

الخادم يعمل على `http://localhost:5000`، وكل المسارات تحت البادئة `/api`.

### الصحة العامة
| الطريقة | المسار | الوصف |
|--------|--------|-------|
| GET | `/api/health` | فحص الحالة (`status: ok`) |

### المصادقة — `/api/auth`
| الطريقة | المسار | الوصف | محمي |
|--------|--------|-------|------|
| POST | `/api/auth/login` | تسجيل الدخول، يُعيد token + user + company | لا |
| GET | `/api/auth/me` | بيانات المستخدم والشركة الحاليين | نعم |
| POST | `/api/auth/logout` | تسجيل الخروج | نعم |

### اللوحة — `/api/dashboard`
| الطريقة | المسار | الوصف | محمي |
|--------|--------|-------|------|
| GET | `/api/dashboard/stats` | إحصائيات: totalFiles, newThisWeek, folders[] | نعم |

### الملفات — `/api/files`
| الطريقة | المسار | الوصف | محمي |
|--------|--------|-------|------|
| GET | `/api/files` | قائمة الملفات (مع `category`, `search`, `page`, `limit`, `sort`, `order`) | نعم |
| GET | `/api/files/:id` | تفاصيل ملف واحد | نعم |
| GET | `/api/files/:id/download` | تنزيل الملف | نعم |
| GET | `/api/files/:id/preview` | بيانات المعاينة | نعم |

**مثال على استعلام فرز/تصفية:**
```
GET /api/files?category=Invoices&search=invoice&page=1&limit=50&sort=created_at&order=desc
```

---

## 7. طريقة التشغيل (How to Run)

### المتطلّبات
- Node.js **22+**
- npm

### 1) تثبيت الاعتماديات

من جذر المشروع:

```bash
npm install --prefix backend
npm install --prefix frontend
```

### 2) إعداد البيئة

```bash
cp backend/.env.example backend/.env
```

القيم التلقائية كافية للتشغيل محلياً، ويمكن تعديلها حسب الحاجة:

| المتغير | الافتراضي | الوصف |
|---------|-----------|-------|
| `PORT` | `5000` | منفذ الخادم |
| `NODE_ENV` | `development` | بيئة التشغيل |
| `JWT_SECRET` | `aych_portal_...` | مفتاح توقيع JWT (يتغيّر في الإنتاج!) |
| `JWT_EXPIRES_IN` | `24h` | صلاحية التوكن |
| `CORS_ORIGIN` | `http://localhost:5173` | أصل الواجهة |
| `DB_PATH` | `portal.db` | مسار قاعدة البيانات |

> **الأمان:** في الإنتاج يجب وضع `JWT_SECRET` قوي وعشوائي، وعدم استخدام القيمة الافتراضية.

### 3) تهيئة قاعدة البيانات بالبيانات التجريبية

```bash
npm run seed
```

هذا يُنشئ الجداول (تلقائياً عبر `db.js`) ويزرع:
- شركة **Waha Oil Company** (الكود `WAHA`).
- مستخدم: **wahaoil** — كلمة المرور: **password123** (دور admin).
- 4 مجلدات + عشرات الملفات التجريبية.

> ملاحظة: ترتيب التشغيل مهم — شغّل `seed` بعد تثبيت اعتماديات الخلفية.

### 4) تشغيل الخادم (Backend)

```bash
npm run start:backend
```
- يعمل على `http://localhost:5000`.

أو للتطوير مع إعادة التشغيل التلقائي:
```bash
cd backend && npm run dev
```

### 5) تشغيل الواجهة (Frontend)

```bash
npm run start:frontend
```
- يعمل على `http://localhost:5173`، ويوجّه طلبات `/api` تلقائياً إلى الخادم (عبر Vite proxy).

افتح المتصفح على **http://localhost:5173** وسجّل الدخول بـ:
```
username: wahaoil
password: password123
```

---

## 8. السكربتات (Scripts)

### من جذر المشروع (`package.json`)
| السكربت | الوصف |
|---------|-------|
| `npm run start:backend` | تشغيل الخادم |
| `npm run start:frontend` | تشغيل واجهة التطوير Vite |
| `npm run seed` | زرع البيانات التجريبية |
| `npm run build` | بناء الواجهة للإنتاج (`vite build`) |

### داخل `backend/`
| السكربت | الوصف |
|---------|-------|
| `npm start` | تشغيل الخادم |
| `npm run dev` | تشغيل مع `--watch` |
| `npm run db:seed` | زرع البيانات |
| `npm run test:check` | فحص صياغة الملفات |

### داخل `frontend/`
| السكربت | الوصف |
|---------|-------|
| `npm run dev` | خادم تطوير Vite |
| `npm run build` | بناء الإنتاج |
| `npm run preview` | معاينة ناتج البناء |

---

## 9. الترجمة واللغة (i18n)

- قواميس الترجمة في `frontend/src/translations/{en,ar}.js`.
- دالة الترجمة `t(key)` تُعاد القيمة من القاموس حسب اللغة الحالية.
- تبديل اللغة فوري (بدون إعادة تحميل) عبر `LanguageToggle`.
- عند اختيار العربية يُضبط `dir="rtl"` تلقائياً على الصفحة.
- اللغة محفوظة في `localStorage` (المفتاح `aych_portal_lang`) لتبقى بعد إعادة التحميل.

---

## 10. قيود وتحسينات مقترحة (Limitations / Roadmap)

- **التنزيل والطُّقم:** دالة `downloadFile` تُعيد **نصاً وصفياً** (metadata) بدلاً من الملف الفعلي؛ و `file_url` مُخزّن في قاعدة البيانات لكن لا يوجد مخزّن ملفات حقيقي (مثل S3 أو مجلد محلي).
- **المصادقة:** الـ `user_sessions` معرّفة في المخطط لكن التطبيق يعتمد على JWT غير قابل للإلغاء فورياً.
- **الترجمة:** بعض رسائل الأخطاء القادمة من الخادم بالإنجليزية (مثل "Invalid username or password") — يمكن ربطها بمفاتيح ترجمة لتحسين الاتساق.
- **الاختبارات:** لا توجد مجموعة اختبارات حالياً؛ يمكن إضافة اختبارات وحدة للـ validators/controllers واختبارات مكوّنات للواجهة.
- **الإنتاج:** تنفيذ خادم إنتاج (PM2/Docker)، وحماية أعمق للرؤوس، وتفعيل `helmet` CSP، وتوليد `JWT_SECRET` آمن.

---

## 11. المصادقة والدور (Auth & Roles)

- كلمة المرور مُخزّنة **مجزّأة** (bcrypt) وليست نصاً صريحاً.
- التوكن (`JWT`) يُرسل عبر كعكة httpOnly ورأس `Authorization`.
- نطاق كل طلبات الملفات واللوحة محدود تلقائياً بالشركة المحمّلة في `req.company`، فلا يمكن لمستخدم شركة رؤية بيانات شركة أخرى.
