import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { en } from '../translations/en.js';
import { ar } from '../translations/ar.js';

const LanguageContext = createContext(null);

export const LanguageProvider = ({ children }) => {
  const [lang, setLang] = useState(() => {
    return localStorage.getItem('aych_portal_lang') || 'en';
  });

  useEffect(() => {
    localStorage.setItem('aych_portal_lang', lang);
    const isRtl = lang === 'ar';
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  const toggleLanguage = () => {
    setLang((prev) => (prev === 'en' ? 'ar' : 'en'));
  };

  const t = (key) => {
    const dict = lang === 'ar' ? ar : en;
    return dict[key] || key;
  };

  const isRtl = useMemo(() => lang === 'ar', [lang]);

  const value = useMemo(
    () => ({
      lang,
      isRtl,
      toggleLanguage,
      t
    }),
    [lang, isRtl]
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
