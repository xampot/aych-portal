import React from 'react';
import { Languages } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.jsx';

export const LanguageToggle = ({ className = '' }) => {
  const { lang, toggleLanguage, t } = useLanguage();

  return (
    <button
      type="button"
      onClick={toggleLanguage}
      className={`lang-toggle-btn ${className}`}
      aria-label="Toggle language"
    >
      <Languages size={18} className="lang-icon" />
      <span className="lang-label">{t('languageToggle')}</span>
    </button>
  );
};
