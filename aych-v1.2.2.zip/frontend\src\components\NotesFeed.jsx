import React, { useState } from 'react';
import { Plus, X, Send, MessageCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';
import { NoteCard } from './NoteCard.jsx';
import { LoadingSpinner } from './LoadingSpinner.jsx';

export const NotesFeed = ({ notes, loading, error, onCreateNote, onReply, onDelete, onEdit }) => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const isAdmin = user?.role === 'admin';

  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newBody, setNewBody] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleCreate = async () => {
    if (!newTitle.trim() || !newBody.trim() || submitting) return;
    setSubmitting(true);
    try {
      await onCreateNote(newTitle.trim(), newBody.trim());
      setNewTitle('');
      setNewBody('');
      setShowCreateForm(false);
    } catch (err) {
      // Error handled by parent
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="table-card">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="notes-feed">
      {isAdmin && (
        <div className="notes-header">
          {!showCreateForm ? (
            <button
              type="button"
              className="btn-primary notes-create-btn"
              onClick={() => setShowCreateForm(true)}
            >
              <Plus size={16} />
              <span>{t('newUpdate')}</span>
            </button>
          ) : (
            <div className="notes-create-form">
              <div className="notes-create-header">
                <h3 className="notes-create-title">{t('newStatusUpdate')}</h3>
                <button
                  type="button"
                  className="modal-close-btn"
                  onClick={() => {
                    setShowCreateForm(false);
                    setNewTitle('');
                    setNewBody('');
                  }}
                >
                  <X size={18} />
                </button>
              </div>
              <input
                type="text"
                className="notes-create-input"
                placeholder={t('updateTitle')}
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
              />
              <textarea
                className="notes-create-textarea"
                placeholder={t('updateBody')}
                value={newBody}
                onChange={(e) => setNewBody(e.target.value)}
                rows={3}
              />
              <div className="notes-create-actions">
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => {
                    setShowCreateForm(false);
                    setNewTitle('');
                    setNewBody('');
                  }}
                >
                  {t('cancel')}
                </button>
                <button
                  type="button"
                  className="btn-primary"
                  onClick={handleCreate}
                  disabled={!newTitle.trim() || !newBody.trim() || submitting}
                >
                  <Send size={15} />
                  <span>{submitting ? t('posting') : t('postUpdate')}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {error && (
        <div className="notes-error">
          <span>{error}</span>
        </div>
      )}

      {!loading && notes.length === 0 && (
        <div className="notes-empty">
          <div className="empty-state-container">
            <div className="empty-state-icon-box">
              <MessageCircle size={32} />
            </div>
            <h3 className="empty-state-title">{t('noUpdatesYet')}</h3>
            <p className="empty-state-message">{t('noUpdatesMessage')}</p>
          </div>
        </div>
      )}

      <div className="notes-list">
        {notes.map((note) => (
          <NoteCard
            key={note.id}
            note={note}
            onReply={onReply}
            onDelete={onDelete}
            onEdit={onEdit}
          />
        ))}
      </div>
    </div>
  );
};
