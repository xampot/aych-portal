import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';

export const useNotes = (projectId) => {
  const { token } = useAuth();
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchNotes = useCallback(async () => {
    if (!token || !projectId) return;
    setLoading(true);
    setError(null);
    try {
      const data = await api.getNotes(token, projectId);
      setNotes(data);
    } catch (err) {
      setError(err.message || 'Failed to load notes');
    } finally {
      setLoading(false);
    }
  }, [token, projectId]);

  useEffect(() => {
    fetchNotes();
  }, [fetchNotes]);

  const createNote = useCallback(async (title, body) => {
    const newNote = await api.createNote(token, { projectId, title, body });
    setNotes((prev) => [newNote, ...prev]);
    return newNote;
  }, [token, projectId]);

  const replyToNote = useCallback(async (noteId, body) => {
    const reply = await api.replyToNote(token, noteId, body);
    setNotes((prev) =>
      prev.map((note) =>
        note.id === noteId
          ? { ...note, replies: [...note.replies, reply] }
          : note
      )
    );
    return reply;
  }, [token]);

  const deleteNote = useCallback(async (noteId) => {
    await api.deleteNote(token, noteId);
    setNotes((prev) => prev.filter((note) => note.id !== noteId));
  }, [token]);

  const editNote = useCallback(async (noteId, title, body) => {
    const updatedNote = await api.editNote(token, noteId, { title, body });
    setNotes((prev) =>
      prev.map((note) =>
        note.id === noteId
          ? { ...note, title: updatedNote.title, body: updatedNote.body, updatedAt: updatedNote.updatedAt }
          : note
      )
    );
    return updatedNote;
  }, [token]);

  return {
    notes,
    loading,
    error,
    createNote,
    replyToNote,
    deleteNote,
    editNote,
    refetch: fetchNotes
  };
};
