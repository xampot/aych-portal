import React from 'react';
import { FolderOpen } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.jsx';

export const EmptyState = ({ message, onReset }) => {
  const { t } = useLanguage();

  return (
    <div className="empty-state-container">
      <div className="empty-state-icon-box">
        <FolderOpen size={48} className="empty-state-icon" />
      </div>
      <h3 className="empty-state-title">{t('noFilesFound')}</h3>
      <p className="empty-state-message">{message || t('noFilesMatchingFilter')}</p>
      {onReset && (
        <button type="button" className="empty-state-btn" onClick={onReset}>
          {t('all')}
        </button>
      )}
    </div>
  );
};
