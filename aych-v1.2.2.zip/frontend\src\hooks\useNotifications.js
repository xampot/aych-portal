import { useState, useEffect, useCallback, useRef } from 'react';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';

export const useNotifications = (projectId) => {
  const { token } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const intervalRef = useRef(null);
  const prevCountRef = useRef(0);

  const fetchNotifications = useCallback(async () => {
    if (!token) return;
    try {
      const data = await api.getNotifications(token, projectId);
      setNotifications(data);
    } catch (err) {
      // silent
    }
  }, [token, projectId]);

  const fetchUnreadCount = useCallback(async () => {
    if (!token) return;
    try {
      const count = await api.getUnreadCount(token, projectId);
      setUnreadCount((prev) => {
        if (count > prev) {
          fetchNotifications();
        }
        return count;
      });
    } catch (err) {
      // silent
    }
  }, [token, projectId, fetchNotifications]);

  const refresh = useCallback(async () => {
    setLoading(true);
    await Promise.all([fetchNotifications(), fetchUnreadCount()]);
    setLoading(false);
  }, [fetchNotifications, fetchUnreadCount]);

  const markAsRead = useCallback(async (id) => {
    if (!token) return;
    const notif = notifications.find((n) => n.id === id);
    if (notif && notif.is_read) return;
    try {
      await api.markNotificationRead(token, id);
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, is_read: 1 } : n))
      );
      setUnreadCount((prev) => Math.max(0, prev - 1));
    } catch (err) {
      // silent
    }
  }, [token, notifications]);

  const markAllAsRead = useCallback(async () => {
    if (!token) return;
    try {
      await api.markAllNotificationsRead(token, projectId);
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: 1 })));
      setUnreadCount(0);
    } catch (err) {
      // silent
    }
  }, [token, projectId]);

  useEffect(() => {
    refresh();
    intervalRef.current = setInterval(() => {
      fetchUnreadCount();
    }, 15000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [refresh, fetchUnreadCount]);

  return {
    notifications,
    unreadCount,
    loading,
    markAsRead,
    markAllAsRead,
    refresh
  };
};
