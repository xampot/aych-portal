import React, { useEffect, useState } from 'react';
import { X, Download, FileText, Image as ImageIcon, StickyNote, CheckCircle2, File, Table, ExternalLink } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.jsx';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';

export const FilePreviewModal = ({ file, onClose, onDownload }) => {
  const { t } = useLanguage();
  const { token } = useAuth();
  const [details, setDetails] = useState(null);
  const [loading, setLoading] = useState(true);

  const getCategoryIcon = (category) => {
    const cat = (category || '').toLowerCase();
    if (cat.includes('document') || cat.includes('contract') || cat.includes('report') || cat.includes('عقود') || cat.includes('تقارير') || cat.includes('مستندات')) {
      return <FileText size={32} />;
    }
    if (cat.includes('gallery') || cat.includes('image') || cat.includes('صور') || cat.includes('معرض')) {
      return <ImageIcon size={32} />;
    }
    if (cat.includes('note') || cat.includes('invoice') || cat.includes('ملاحظات') || cat.includes('فواتير')) {
      return <StickyNote size={32} />;
    }
    return <FileText size={32} />;
  };

  useEffect(() => {
    let isMounted = true;
    const loadDetails = async () => {
      try {
        const data = await api.getFilePreview(file.id, token);
        if (isMounted) setDetails(data);
      } catch (err) {
        if (isMounted) setDetails(file);
      } finally {
        if (isMounted) setLoading(false);
      }
    };
    loadDetails();
    return () => {
      isMounted = false;
    };
  }, [file, token]);

  const mime = file.mimeType || file.mime_type || '';
  const fileName = (file.name || '').toLowerCase();
  const isImage = mime.startsWith('image/');
  const isPdf = mime === 'application/pdf';
  const isText = mime.startsWith('text/');
  const isCsv = fileName.endsWith('.csv') || mime === 'text/csv';
  const isExcel = fileName.endsWith('.xls') || fileName.endsWith('.xlsx') || mime.includes('spreadsheet') || mime.includes('excel');
  const isWord = fileName.endsWith('.doc') || fileName.endsWith('.docx') || mime.includes('word') || mime.includes('document');
  const isPpt = fileName.endsWith('.ppt') || fileName.endsWith('.pptx') || mime.includes('presentation') || mime.includes('powerpoint');
  const isOffice = isExcel || isWord || isPpt;
  const fileUrl = file.fileUrl || file.file_url;
  const hasActualFile = fileUrl && fileUrl.startsWith('/uploads/');

  const getGoogleDocsUrl = (url) => {
    const fullUrl = window.location.origin + url;
    return `https://docs.google.com/gview?url=${encodeURIComponent(fullUrl)}&embedded=true`;
  };

  const isMobile = /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

  const renderPreview = () => {
    if (!hasActualFile) {
      return (
        <div className="preview-not-available">
          <File size={48} />
          <p>{t('previewNotAvailable')}</p>
          <p className="preview-hint">{t('downloadToView')}</p>
        </div>
      );
    }

    if (isImage) {
      return (
        <div className="preview-image-wrapper">
          <img src={fileUrl} alt={file.name} className="preview-image" />
        </div>
      );
    }

    if (isPdf) {
      if (isMobile) {
        return (
          <div className="preview-pdf-mobile">
            <div className="preview-pdf-mobile-icon">
              <FileText size={48} />
            </div>
            <p className="preview-pdf-mobile-text">{t('previewNotSupported')}</p>
            <a
              href={fileUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="preview-pdf-mobile-btn"
            >
              <ExternalLink size={16} />
              <span>{t('openInNewTab')}</span>
            </a>
          </div>
        );
      }
      return (
        <div className="preview-pdf-wrapper">
          <iframe src={fileUrl} className="preview-pdf" title={file.name} />
        </div>
      );
    }

    if (isCsv) {
      return <CsvPreview url={fileUrl} />;
    }

    if (isOffice) {
      if (isMobile) {
        return (
          <div className="preview-pdf-mobile">
            <div className="preview-pdf-mobile-icon">
              <FileText size={48} />
            </div>
            <p className="preview-pdf-mobile-text">{t('previewNotSupported')}</p>
            <a
              href={fileUrl}
              download={file.name}
              className="preview-pdf-mobile-btn"
            >
              <Download size={16} />
              <span>{t('downloadToView')}</span>
            </a>
          </div>
        );
      }
      return (
        <div className="preview-office-wrapper">
          <iframe
            src={getGoogleDocsUrl(fileUrl)}
            className="preview-office"
            title={file.name}
          />
        </div>
      );
    }

    if (isText) {
      return <TextPreview url={fileUrl} />;
    }

    return (
      <div className="preview-not-available">
        <File size={48} />
        <p>{t('previewNotSupported')}</p>
        <p className="preview-hint">{t('downloadToView')}</p>
      </div>
    );
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container modal-preview" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div className="modal-title-box">
            <FileText size={20} className="modal-icon" />
            <h3 className="modal-title">{t('documentPreview')}</h3>
          </div>
          <button type="button" className="modal-close-btn" onClick={onClose} aria-label="Close">
            <X size={20} />
          </button>
        </div>

        <div className="modal-body">
          <div className="modal-file-banner">
            <div className="modal-file-icon">
              {getCategoryIcon(file.category)}
            </div>
            <div className="modal-file-meta">
              <h4 className="modal-file-name">{file.name}</h4>
              <span className="modal-file-category">{file.category}</span>
            </div>
          </div>

          <div className="modal-info-grid">
            <div className="modal-info-item">
              <span className="info-label">{t('size')}</span>
              <span className="info-value">{file.formattedSize || file.formatted_size}</span>
            </div>
            <div className="modal-info-item">
              <span className="info-label">{t('date')}</span>
              <span className="info-value">{file.createdAt ? file.createdAt.split(' ')[0] : '-'}</span>
            </div>
            <div className="modal-info-item">
              <span className="info-label">{t('category')}</span>
              <span className="info-value">{file.category}</span>
            </div>
            <div className="modal-info-item">
              <span className="info-label">{t('companyVerification')}</span>
              <span className="info-value modal-verified">
                <CheckCircle2 size={15} />
                <span>{details?.company || 'Verified'}</span>
              </span>
            </div>
          </div>

          <div className="preview-section">
            {renderPreview()}
          </div>
        </div>

        <div className="modal-footer">
          <button type="button" className="btn-secondary" onClick={onClose}>
            {t('close')}
          </button>
          <button
            type="button"
            className="btn-primary modal-download-btn"
            onClick={() => onDownload(file)}
          >
            <Download size={16} />
            <span>{t('downloadDocument')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

function parseCsv(text) {
  const rows = [];
  let current = '';
  let inQuotes = false;
  let row = [];

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        current += ch;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
      } else if (ch === ',') {
        row.push(current.trim());
        current = '';
      } else if (ch === '\n' || ch === '\r') {
        if (ch === '\r' && text[i + 1] === '\n') i++;
        row.push(current.trim());
        if (row.some(c => c !== '')) rows.push(row);
        row = [];
        current = '';
      } else {
        current += ch;
      }
    }
  }
  row.push(current.trim());
  if (row.some(c => c !== '')) rows.push(row);
  return rows;
}

function CsvPreview({ url }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    let isMounted = true;
    fetch(url)
      .then((res) => {
        if (!res.ok) throw new Error('Failed to load');
        return res.text();
      })
      .then((text) => {
        if (isMounted) setRows(parseCsv(text));
      })
      .catch(() => {
        if (isMounted) setError(true);
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });
    return () => { isMounted = false; };
  }, [url]);

  if (loading) return <div className="preview-loading">Loading...</div>;
  if (error) return <div className="preview-not-available"><File size={48} /><p>Failed to load preview</p></div>;
  if (rows.length === 0) return <div className="preview-not-available"><File size={48} /><p>Empty file</p></div>;

  const [header, ...body] = rows;
  const maxCols = Math.max(header.length, ...body.map(r => r.length));

  return (
    <div className="preview-csv-wrapper">
      <table className="preview-csv-table">
        <thead>
          <tr>
            {header.map((cell, i) => (
              <th key={i}>{cell || '\u00A0'}</th>
            ))}
            {header.length < maxCols && Array.from({ length: maxCols - header.length }).map((_, i) => (
              <th key={`e${i}`}>{'\u00A0'}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {body.map((row, ri) => (
            <tr key={ri}>
              {row.map((cell, ci) => (
                <td key={ci}>{cell || '\u00A0'}</td>
              ))}
              {row.length < maxCols && Array.from({ length: maxCols - row.length }).map((_, i) => (
                <td key={`e${i}`}>{'\u00A0'}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function TextPreview({ url }) {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    let isMounted = true;
    fetch(url)
      .then((res) => {
        if (!res.ok) throw new Error('Failed to load');
        return res.text();
      })
      .then((text) => {
        if (isMounted) setContent(text);
      })
      .catch(() => {
        if (isMounted) setError(true);
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });
    return () => { isMounted = false; };
  }, [url]);

  if (loading) return <div className="preview-loading">Loading...</div>;
  if (error) return <div className="preview-not-available"><File size={48} /><p>Failed to load preview</p></div>;

  return (
    <div className="preview-text-wrapper">
      <pre className="preview-text-content">{content}</pre>
    </div>
  );
}
