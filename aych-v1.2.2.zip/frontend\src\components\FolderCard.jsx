import React from 'react';
import { FileText, Receipt, BarChart3, Image as ImageIcon, StickyNote, ChevronRight, ChevronLeft } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.jsx';

export const FolderCard = ({ slug, nameEn, nameAr, count, color, isSelected, onClick }) => {
  const { lang, isRtl, t } = useLanguage();

  const getFolderIcon = () => {
    switch (slug) {
      case 'documents':
        return <FileText size={22} className="folder-icon" />;
      case 'gallery':
        return <ImageIcon size={22} className="folder-icon" />;
      case 'notes':
        return <StickyNote size={22} className="folder-icon" />;
      case 'contracts':
        return <FileText size={22} className="folder-icon" />;
      case 'invoices':
        return <Receipt size={22} className="folder-icon" />;
      case 'reports':
        return <BarChart3 size={22} className="folder-icon" />;
      case 'images':
        return <ImageIcon size={22} className="folder-icon" />;
      default:
        return <FileText size={22} className="folder-icon" />;
    }
  };

  const displayName = lang === 'ar' ? (nameAr || nameEn) : (nameEn || nameAr);

  return (
    <div
      className={`folder-card folder-card-${color} ${isSelected ? 'folder-card-active' : ''}`}
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          onClick();
        }
      }}
    >
      <div className={`folder-icon-box folder-icon-box-${color}`}>
        {getFolderIcon()}
      </div>
      <div className="folder-details">
        <span className="folder-name">{displayName}</span>
        <span className="folder-count">{count} {t('items')}</span>
      </div>
      <div className="folder-arrow">
        {isRtl ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}
      </div>
    </div>
  );
};
