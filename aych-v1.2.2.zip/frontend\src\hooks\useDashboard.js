import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';

export const useDashboard = (projectId) => {
  const { token } = useAuth();
  const [data, setData] = useState({
    totalFiles: 0,
    newThisWeek: 0,
    folders: []
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchStats = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    setError(null);
    try {
      const stats = await api.getDashboardStats(token, projectId);
      setData(stats);
    } catch (err) {
      setError(err.message || 'Failed to load statistics');
    } finally {
      setLoading(false);
    }
  }, [token, projectId]);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  return {
    stats: data,
    loading,
    error,
    refetch: fetchStats
  };
};
