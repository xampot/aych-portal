import React, { useEffect, useState } from 'react';
import { FolderOpen } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';
import { LanguageToggle } from '../components/LanguageToggle.jsx';
import { LoadingSpinner } from '../components/LoadingSpinner.jsx';
import { api } from '../services/api.js';
import '../styles/projects.css';

export const ProjectsPage = () => {
  const { token, setSelectedProject, logout } = useAuth();
  const { t } = useLanguage();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const res = await api.getProjects(token);
        setProjects(res.data);
      } catch (err) {
        setError(err.message || 'Failed to load projects');
      } finally {
        setLoading(false);
      }
    };

    fetchProjects();
  }, [token]);

  const handleSelect = (project) => {
    setSelectedProject(project);
  };

  if (loading) {
    return (
      <div className="projects-page">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="projects-page">
        <div className="projects-header">
          <h1 className="projects-title">{t('errorOccurred')}</h1>
          <p className="projects-subtitle">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="projects-page">
      <div className="projects-lang-wrapper">
        <LanguageToggle className="login-lang-btn" />
      </div>

      <div className="projects-header">
        <img src="/logo.png" alt="Aych Portal" className="projects-logo" />
        <h1 className="projects-title">{t('selectProject')}</h1>
        <p className="projects-subtitle">{t('selectProjectSubtitle')}</p>
      </div>

      <div className="projects-grid">
        {projects.map((project) => (
          <div
            key={project.id}
            className="project-card"
            onClick={() => handleSelect(project)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                handleSelect(project);
              }
            }}
          >
            <div className="project-icon-box">
              <FolderOpen size={26} />
            </div>
            <span className="project-name">{project.name}</span>
          </div>
        ))}
      </div>

      <div className="projects-footer">
        <button type="button" className="projects-logout-btn" onClick={logout}>
          {t('logout')}
        </button>
      </div>
    </div>
  );
};
