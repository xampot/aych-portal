import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';

export const useFiles = (initialCategory = 'All', projectId) => {
  const { token } = useAuth();
  const [category, setCategory] = useState(initialCategory);
  const [search, setSearch] = useState('');
  const [files, setFiles] = useState([]);
  const [pagination, setPagination] = useState({ total: 0, page: 1, limit: 50, totalPages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchFiles = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    setError(null);
    try {
      const response = await api.getFiles({
        token,
        category,
        search,
        page: 1,
        limit: 50,
        projectId
      });
      setFiles(response.data);
      setPagination(response.pagination);
    } catch (err) {
      setError(err.message || 'Failed to load files');
    } finally {
      setLoading(false);
    }
  }, [token, category, search, projectId]);

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchFiles();
    }, 150);
    return () => clearTimeout(timer);
  }, [fetchFiles]);

  return {
    files,
    pagination,
    loading,
    error,
    category,
    setCategory,
    search,
    setSearch,
    refetch: fetchFiles
  };
};
