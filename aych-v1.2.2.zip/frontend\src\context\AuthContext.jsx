import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { api } from '../services/api.js';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(() => localStorage.getItem('aych_portal_token') || null);
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('aych_portal_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [company, setCompany] = useState(() => {
    const saved = localStorage.getItem('aych_portal_company');
    return saved ? JSON.parse(saved) : null;
  });
  const [selectedProject, setSelectedProjectState] = useState(() => {
    const saved = localStorage.getItem('aych_portal_project');
    return saved ? JSON.parse(saved) : null;
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const verifyExistingToken = async () => {
      if (!token) {
        setLoading(false);
        return;
      }
      try {
        const response = await api.getCurrentUser(token);
        if (response.success) {
          setUser(response.user);
          setCompany(response.company);
          localStorage.setItem('aych_portal_user', JSON.stringify(response.user));
          localStorage.setItem('aych_portal_company', JSON.stringify(response.company));
        } else {
          logout();
        }
      } catch (err) {
        logout();
      } finally {
        setLoading(false);
      }
    };

    verifyExistingToken();
  }, [token]);

  const login = async (username, password) => {
    const res = await api.login(username, password);
    setToken(res.token);
    setUser(res.user);
    setCompany(res.company);
    localStorage.setItem('aych_portal_token', res.token);
    localStorage.setItem('aych_portal_user', JSON.stringify(res.user));
    localStorage.setItem('aych_portal_company', JSON.stringify(res.company));
    return res;
  };

  const setSelectedProject = useCallback((project) => {
    setSelectedProjectState(project);
    localStorage.setItem('aych_portal_project', JSON.stringify(project));
  }, []);

  const clearProject = useCallback(() => {
    setSelectedProjectState(null);
    localStorage.removeItem('aych_portal_project');
  }, []);

  const logout = async () => {
    try {
      if (token) {
        await api.logout(token);
      }
    } catch (err) {
    } finally {
      setToken(null);
      setUser(null);
      setCompany(null);
      setSelectedProjectState(null);
      localStorage.removeItem('aych_portal_token');
      localStorage.removeItem('aych_portal_user');
      localStorage.removeItem('aych_portal_company');
      localStorage.removeItem('aych_portal_project');
    }
  };

  const value = useMemo(
    () => ({
      token,
      user,
      company,
      selectedProject,
      isAuthenticated: Boolean(token && user),
      loading,
      login,
      logout,
      setSelectedProject,
      clearProject
    }),
    [token, user, company, selectedProject, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
