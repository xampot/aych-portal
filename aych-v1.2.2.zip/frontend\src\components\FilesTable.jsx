import React, { useState } from 'react';
import { Eye, Download, Trash2, FileText, Image as ImageIcon, StickyNote, CheckSquare, Square, DownloadCloud, Trash } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { EmptyState } from './EmptyState.jsx';
import { LoadingSpinner } from './LoadingSpinner.jsx';
import { FilePreviewModal } from './FilePreviewModal.jsx';

export const FilesTable = ({ files, loading, onDownload, onResetFilter, selectedIds, onSelectionChange, onBulkDownload, onBulkDelete, onDelete }) => {
  const { lang, t } = useLanguage();
  const { user } = useAuth();
  const [previewTarget, setPreviewTarget] = useState(null);

  const isAdmin = user?.role === 'admin';
  const allSelected = files && files.length > 0 && files.every((f) => selectedIds?.includes(f.id));
  const selectedCount = selectedIds?.length || 0;

  const getCategoryIcon = (category) => {
    const cat = (category || '').toLowerCase();
    if (cat.includes('document') || cat.includes('contract') || cat.includes('report') || cat.includes('عقود') || cat.includes('تقارير') || cat.includes('مستندات')) {
      return (
        <div className="file-icon-box file-icon-box-blue">
          <FileText size={18} />
        </div>
      );
    }
    if (cat.includes('gallery') || cat.includes('image') || cat.includes('صور') || cat.includes('معرض')) {
      return (
        <div className="file-icon-box file-icon-box-amber">
          <ImageIcon size={18} />
        </div>
      );
    }
    if (cat.includes('note') || cat.includes('invoice') || cat.includes('ملاحظات') || cat.includes('فواتير')) {
      return (
        <div className="file-icon-box file-icon-box-teal">
          <StickyNote size={18} />
        </div>
      );
    }
    return (
      <div className="file-icon-box file-icon-box-blue">
        <FileText size={18} />
      </div>
    );
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      const locale = lang === 'ar' ? 'ar-EG' : 'en-GB';
      return d.toLocaleDateString(locale, {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });
    } catch (e) {
      return dateStr;
    }
  };

  const handleToggleAll = () => {
    if (!files) return;
    if (allSelected) {
      onSelectionChange([]);
    } else {
      onSelectionChange(files.map((f) => f.id));
    }
  };

  const handleToggleOne = (fileId) => {
    if (!selectedIds) return;
    if (selectedIds.includes(fileId)) {
      onSelectionChange(selectedIds.filter((id) => id !== fileId));
    } else {
      onSelectionChange([...selectedIds, fileId]);
    }
  };

  if (loading) {
    return (
      <div className="table-card">
        <LoadingSpinner />
      </div>
    );
  }

  if (!files || files.length === 0) {
    return (
      <div className="table-card">
        <EmptyState onReset={onResetFilter} />
      </div>
    );
  }

  return (
    <div className="table-card">
      {isAdmin && selectedCount > 0 && (
        <div className="bulk-actions-bar">
          <span className="bulk-actions-count">{selectedCount} {t('selected')}</span>
          <div className="bulk-actions-buttons">
            <button
              type="button"
              className="btn-secondary bulk-btn"
              onClick={onBulkDownload}
            >
              <DownloadCloud size={15} />
              <span>{t('bulkDownload')}</span>
            </button>
            <button
              type="button"
              className="btn-danger bulk-btn"
              onClick={onBulkDelete}
            >
              <Trash size={15} />
              <span>{t('bulkDelete')}</span>
            </button>
          </div>
        </div>
      )}
      <div className="table-responsive">
        <table className="files-table">
          <thead>
            <tr>
              {isAdmin && (
                <th className="th-checkbox">
                  <button type="button" className="checkbox-btn" onClick={handleToggleAll}>
                    {allSelected ? <CheckSquare size={18} /> : <Square size={18} />}
                  </button>
                </th>
              )}
              <th className="th-name">{t('name')}</th>
              <th className="th-category">{t('category')}</th>
              <th className="th-size">{t('size')}</th>
              <th className="th-date">{t('date')}</th>
              <th className="th-actions">{t('actions')}</th>
            </tr>
          </thead>
          <tbody>
            {files.map((file) => (
              <tr key={file.id} className={`file-row ${selectedIds?.includes(file.id) ? 'file-row-selected' : ''}`}>
                {isAdmin && (
                  <td className="td-checkbox">
                    <button type="button" className="checkbox-btn" onClick={() => handleToggleOne(file.id)}>
                      {selectedIds?.includes(file.id) ? <CheckSquare size={18} /> : <Square size={18} />}
                    </button>
                  </td>
                )}
                <td className="td-name">
                  <div className="file-name-cell">
                    {getCategoryIcon(file.category)}
                    <span className="file-title">{file.name}</span>
                    {file.isNew && <span className="new-tag">{t('newBadge')}</span>}
                  </div>
                </td>
                <td className="td-category" data-label={`${t('category')}:`}>
                  <span className="category-label">{file.category}</span>
                </td>
                <td className="td-size" data-label={`${t('size')}:`}>
                  <span className="size-label">{file.formattedSize || file.formatted_size}</span>
                </td>
                <td className="td-date" data-label={`${t('date')}:`}>
                  <span className="date-label">{formatDate(file.createdAt)}</span>
                </td>
                <td className="td-meta-mobile">
                  <span><span className="meta-label">{t('category')}:</span> {file.category}</span>
                  <span><span className="meta-label">{t('size')}:</span> {file.formattedSize || file.formatted_size}</span>
                  <span><span className="meta-label">{t('date')}:</span> {formatDate(file.createdAt)}</span>
                </td>
                <td className="td-actions">
                  <div className="action-buttons-group">
                    <button
                      type="button"
                      className="action-btn view-btn"
                      onClick={() => setPreviewTarget(file)}
                      aria-label={t('viewDocument')}
                      title={t('viewDocument')}
                    >
                      <Eye size={17} />
                    </button>
                    <button
                      type="button"
                      className="action-btn download-btn"
                      onClick={() => onDownload(file)}
                      aria-label={t('downloadDocument')}
                      title={t('downloadDocument')}
                    >
                      <Download size={17} />
                    </button>
                    {isAdmin && (
                      <button
                        type="button"
                        className="action-btn delete-btn"
                        onClick={() => onDelete(file)}
                        aria-label={t('deleteFile')}
                        title={t('deleteFile')}
                      >
                        <Trash2 size={17} />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {previewTarget && (
        <FilePreviewModal
          file={previewTarget}
          onClose={() => setPreviewTarget(null)}
          onDownload={(f) => {
            setPreviewTarget(null);
            onDownload(f);
          }}
        />
      )}
    </div>
  );
};
