import React, { useState, useRef, useCallback } from 'react';
import { ArrowLeft, Upload, X, FileText, Image, CheckCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';
import { useDashboard } from '../hooks/useDashboard.js';
import { useFiles } from '../hooks/useFiles.js';
import { useNotes } from '../hooks/useNotes.js';
import { Navbar } from '../components/Navbar.jsx';
import { StatCard } from '../components/StatCard.jsx';
import { FolderCard } from '../components/FolderCard.jsx';
import { FilesTable } from '../components/FilesTable.jsx';
import { NotesFeed } from '../components/NotesFeed.jsx';
import { api } from '../services/api.js';

function detectCategory(file) {
  if (file.type && file.type.startsWith('image/')) return 'Gallery';
  const ext = (file.name || '').split('.').pop().toLowerCase();
  const imageExts = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'ico'];
  if (imageExts.includes(ext)) return 'Gallery';
  return 'Documents';
}

function formatFileSize(bytes) {
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

export const DashboardPage = () => {
  const { company, token, user, selectedProject, clearProject } = useAuth();
  const { lang, t } = useLanguage();
  const { stats, loading: statsLoading } = useDashboard(selectedProject?.id);
  const {
    files,
    loading: filesLoading,
    category,
    setCategory,
    search,
    setSearch,
    refetch: refetchFiles
  } = useFiles('All', selectedProject?.id);
  const {
    notes,
    loading: notesLoading,
    error: notesError,
    createNote,
    replyToNote,
    deleteNote,
    editNote
  } = useNotes(selectedProject?.id);

  const [notification, setNotification] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [uploadFileName, setUploadFileName] = useState('');
  const [uploadCategory, setUploadCategory] = useState('Documents');
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [selectedIds, setSelectedIds] = useState([]);
  const fileInputRef = useRef(null);

  const categories = [
    { key: 'All', labelEn: 'All', labelAr: 'الكل' },
    { key: 'Documents', labelEn: 'Documents', labelAr: 'المستندات' },
    { key: 'Gallery', labelEn: 'Gallery', labelAr: 'المعرض' },
    { key: 'Notes', labelEn: 'Notes', labelAr: 'الملاحظات' }
  ];

  const isNotesSelected = category === 'Notes';

  const handleDownload = async (file) => {
    try {
      await api.downloadFile(file.id, file.name, token);
      showNotification(`${t('downloadStarted')}: ${file.name}`);
    } catch (err) {
      showNotification(err.message || 'Download failed');
    }
  };

  const handleDeleteFile = async (file) => {
    if (!window.confirm(t('confirmDeleteFile'))) return;
    try {
      await api.deleteFile(token, file.id);
      showNotification(t('fileDeleted'));
      refetchFiles();
    } catch (err) {
      showNotification(err.message || 'Failed to delete file');
    }
  };

  const handleCreateNote = async (title, body) => {
    try {
      await createNote(title, body);
      showNotification(t('noteCreated'));
    } catch (err) {
      showNotification(err.message || 'Failed to create note');
    }
  };

  const handleReply = async (noteId, body) => {
    try {
      await replyToNote(noteId, body);
      showNotification(t('replySent'));
    } catch (err) {
      showNotification(err.message || 'Failed to send reply');
    }
  };

  const handleDeleteNote = async (noteId) => {
    try {
      await deleteNote(noteId);
      showNotification(t('noteDeleted'));
    } catch (err) {
      showNotification(err.message || 'Failed to delete note');
    }
  };

  const handleEditNote = async (noteId, title, body) => {
    try {
      await editNote(noteId, title, body);
      showNotification(t('noteUpdated'));
    } catch (err) {
      showNotification(err.message || 'Failed to update note');
    }
  };

  const handleBulkDownload = async () => {
    const selectedFiles = files.filter((f) => selectedIds.includes(f.id));
    for (const file of selectedFiles) {
      try {
        await api.downloadFile(file.id, file.name, token);
      } catch (err) {
        showNotification(err.message || 'Download failed');
      }
    }
    showNotification(`${t('downloadStarted')}: ${selectedFiles.length} files`);
    setSelectedIds([]);
  };

  const handleBulkDelete = async () => {
    if (!window.confirm(t('confirmDelete'))) return;
    try {
      await api.bulkDeleteFiles(token, selectedIds);
      showNotification(`${selectedIds.length} ${t('filesDeleted')}`);
      setSelectedIds([]);
      refetchFiles();
    } catch (err) {
      showNotification(err.message || 'Failed to delete files');
    }
  };

  const handleFileSelect = useCallback((files) => {
    const newItems = Array.from(files).map((f) => ({
      file: f,
      name: f.name.replace(/\.[^/.]+$/, ''),
      category: detectCategory(f)
    }));
    setSelectedFiles((prev) => [...prev, ...newItems]);
  }, []);

  const handleRemoveFile = (index) => {
    setSelectedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleUpdateFileName = (index, name) => {
    setSelectedFiles((prev) => prev.map((item, i) => i === index ? { ...item, name } : item));
  };

  const handleDrag = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelect(e.dataTransfer.files);
    }
  }, [handleFileSelect]);

  const handleFileInputChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFileSelect(e.target.files);
    }
  };

  const handleUpload = async () => {
    if (selectedFiles.length === 0 || !selectedProject?.id || uploading) return;
    setUploading(true);
    try {
      await api.uploadFile(token, {
        files: selectedFiles,
        projectId: selectedProject.id
      });
      showNotification(`${selectedFiles.length} ${t('filesUploaded')}`);
      setSelectedFiles([]);
      setShowUploadModal(false);
      refetchFiles();
    } catch (err) {
      showNotification(err.message || 'Failed to upload files');
    } finally {
      setUploading(false);
    }
  };

  const handleCloseModal = () => {
    setShowUploadModal(false);
    setSelectedFiles([]);
    setDragActive(false);
  };

  const showNotification = (msg) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 3000);
  };

  const companyName = company?.name || 'Waha Oil Company';
  const projectName = selectedProject?.name || '';

  return (
    <div className="portal-layout">
      <Navbar search={search} onSearchChange={setSearch} />

      {notification && (
        <div className="toast-notification">
          <span>{notification}</span>
        </div>
      )}

      <main className="portal-main">
        <div className="portal-container">
          <section className="welcome-section">
            <div className="welcome-header-row">
              <div>
                <span className="welcome-subtitle">{t('welcomeBack')}</span>
                <h1 className="welcome-title">{projectName}</h1>
                <span className="welcome-company">{companyName}</span>
              </div>
              <button
                type="button"
                className="switch-project-btn"
                onClick={clearProject}
                title={t('switchProject')}
              >
                <ArrowLeft size={16} />
                <span>{t('switchProject')}</span>
              </button>
            </div>
          </section>

          <section className="stats-section">
            <div className="stats-grid">
              <StatCard
                type="totalFiles"
                count={statsLoading ? '...' : stats.totalFiles}
                label={t('totalFiles')}
              />
              <StatCard
                type="newThisWeek"
                count={statsLoading ? '...' : stats.newThisWeek}
                label={t('newThisWeek')}
              />
            </div>
          </section>

          <section className="folders-section">
            <h2 className="section-title">{t('folders')}</h2>
            <div className="folders-grid">
              {stats.folders && stats.folders.length > 0 ? (
                stats.folders.map((f) => (
                  <FolderCard
                    key={f.id || f.slug}
                    slug={f.slug}
                    nameEn={f.nameEn}
                    nameAr={f.nameAr}
                    count={f.count}
                    color={f.color}
                    isSelected={category.toLowerCase() === f.slug.toLowerCase() || category === f.nameEn}
                    onClick={() => {
                      if (category.toLowerCase() === f.slug.toLowerCase() || category === f.nameEn) {
                        setCategory('All');
                      } else {
                        setCategory(f.nameEn);
                      }
                    }}
                  />
                ))
              ) : (
                <div className="folders-loading-placeholder">
                  {statsLoading ? t('loadingData') : null}
                </div>
              )}
            </div>
          </section>

          <section className="files-section">
            <div className="files-section-header">
              <h2 className="section-title">{isNotesSelected ? t('statusUpdates') : t('allFiles')}</h2>
              {!isNotesSelected && user?.role === 'admin' && (
                <button
                  type="button"
                  className="btn-primary upload-btn"
                  onClick={() => setShowUploadModal(true)}
                >
                  <Upload size={16} />
                  <span>{t('uploadFile')}</span>
                </button>
              )}
            </div>

            <div className="category-pills-row">
              {categories.map((c) => {
                const isSelected = category === c.key || (category === 'All' && c.key === 'All');
                const label = lang === 'ar' ? c.labelAr : c.labelEn;
                return (
                  <button
                    key={c.key}
                    type="button"
                    className={`category-pill ${isSelected ? 'category-pill-active' : ''}`}
                    onClick={() => setCategory(c.key)}
                  >
                    {label}
                  </button>
                );
              })}
            </div>

            {isNotesSelected ? (
              <NotesFeed
                notes={notes}
                loading={notesLoading}
                error={notesError}
                onCreateNote={handleCreateNote}
                onReply={handleReply}
                onDelete={handleDeleteNote}
                onEdit={handleEditNote}
              />
            ) : (
              <FilesTable
                files={files}
                loading={filesLoading}
                onDownload={handleDownload}
                onResetFilter={() => {
                  setCategory('All');
                  setSearch('');
                }}
                selectedIds={selectedIds}
                onSelectionChange={setSelectedIds}
                onBulkDownload={handleBulkDownload}
                onBulkDelete={handleBulkDelete}
                onDelete={handleDeleteFile}
              />
            )}
          </section>
        </div>
      </main>

      {showUploadModal && (
        <div className="modal-overlay" onClick={handleCloseModal}>
          <div className="modal-container" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3 className="modal-title">{t('uploadFile')}</h3>
              <button
                type="button"
                className="modal-close-btn"
                onClick={handleCloseModal}
              >
                <X size={18} />
              </button>
            </div>
            <div className="modal-body">
              {selectedFiles.length === 0 ? (
                <div
                  className={`drop-zone ${dragActive ? 'drop-zone-active' : ''}`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    className="drop-zone-input"
                    multiple
                    onChange={handleFileInputChange}
                    accept="image/*,.pdf,.doc,.docx,.txt,.xls,.xlsx,.ppt,.pptx,.csv"
                  />
                  <Upload size={40} className="drop-zone-icon" />
                  <p className="drop-zone-text">{t('dropFileHere')}</p>
                  <p className="drop-zone-hint">{t('orClickToBrowse')}</p>
                  <p className="drop-zone-formats">{t('supportedFormats')}</p>
                </div>
              ) : (
                <div className="upload-files-list">
                  {selectedFiles.map((item, index) => (
                    <div key={index} className="upload-file-item">
                      <div className="upload-file-info">
                        <div className="upload-file-icon-box">
                          {item.category === 'Gallery' ? (
                            <Image size={20} />
                          ) : (
                            <FileText size={20} />
                          )}
                        </div>
                        <div className="upload-file-details">
                          <input
                            type="text"
                            className="upload-file-name-input"
                            value={item.name}
                            onChange={(e) => handleUpdateFileName(index, e.target.value)}
                          />
                          <span className="upload-file-meta">
                            {formatFileSize(item.file.size)} · {item.category}
                          </span>
                        </div>
                        <button
                          type="button"
                          className="upload-file-remove"
                          onClick={() => handleRemoveFile(index)}
                        >
                          <X size={16} />
                        </button>
                      </div>
                    </div>
                  ))}
                  <div
                    className={`drop-zone drop-zone-compact ${dragActive ? 'drop-zone-active' : ''}`}
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      className="drop-zone-input"
                      multiple
                      onChange={handleFileInputChange}
                      accept="image/*,.pdf,.doc,.docx,.txt,.xls,.xlsx,.ppt,.pptx,.csv"
                    />
                    <Upload size={20} className="drop-zone-icon" />
                    <span className="drop-zone-text-compact">{t('addMoreFiles')}</span>
                  </div>
                </div>
              )}
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn-secondary"
                onClick={handleCloseModal}
                disabled={uploading}
              >
                {t('cancel')}
              </button>
              <button
                type="button"
                className="btn-primary"
                onClick={handleUpload}
                disabled={selectedFiles.length === 0 || uploading}
              >
                <Upload size={15} />
                <span>{uploading ? t('uploading') : t('upload')}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
