import React, { useState } from 'react';
import { MessageCircle, Trash2, Send, Pencil, X, Check } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';

export const NoteCard = ({ note, onReply, onDelete, onEdit }) => {
  const { user } = useAuth();
  const { lang, t } = useLanguage();
  const [replyText, setReplyText] = useState('');
  const [showReplyInput, setShowReplyInput] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(note.title);
  const [editBody, setEditBody] = useState(note.body);

  const isAdmin = user?.role === 'admin';

  const formatDateTime = (dateStr) => {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      const locale = lang === 'ar' ? 'ar-EG' : 'en-GB';
      return d.toLocaleDateString(locale, {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (e) {
      return dateStr;
    }
  };

  const handleReply = async () => {
    if (!replyText.trim() || submitting) return;
    setSubmitting(true);
    try {
      await onReply(note.id, replyText.trim());
      setReplyText('');
      setShowReplyInput(false);
    } catch (err) {
      // Error handled by parent
    } finally {
      setSubmitting(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleReply();
    }
  };

  const handleEdit = async () => {
    if (!editTitle.trim() || !editBody.trim() || submitting) return;
    setSubmitting(true);
    try {
      await onEdit(note.id, editTitle.trim(), editBody.trim());
      setIsEditing(false);
    } catch (err) {
      // Error handled by parent
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancelEdit = () => {
    setEditTitle(note.title);
    setEditBody(note.body);
    setIsEditing(false);
  };

  const handleEditKeyDown = (e) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      e.preventDefault();
      handleEdit();
    }
    if (e.key === 'Escape') {
      handleCancelEdit();
    }
  };

  return (
    <div className="note-card">
      <div className="note-header">
        <div className="note-user-info">
          <div className="note-avatar">
            {note.user.initials}
          </div>
          <div className="note-meta">
            <span className="note-author">{note.user.fullName}</span>
            <span className="note-role">{note.user.role}</span>
            <span className="note-date">{formatDateTime(note.createdAt)}</span>
          </div>
        </div>
        {isAdmin && (
          <div className="note-admin-actions">
            <button
              type="button"
              className="note-edit-btn"
              onClick={() => setIsEditing(true)}
              title={t('editNote')}
            >
              <Pencil size={15} />
            </button>
            <button
              type="button"
              className="note-delete-btn"
              onClick={() => onDelete(note.id)}
              title={t('deleteNote')}
            >
              <Trash2 size={15} />
            </button>
          </div>
        )}
      </div>

      {isEditing ? (
        <div className="note-edit-form">
          <input
            type="text"
            className="note-edit-title"
            value={editTitle}
            onChange={(e) => setEditTitle(e.target.value)}
            onKeyDown={handleEditKeyDown}
            autoFocus
          />
          <textarea
            className="note-edit-body"
            value={editBody}
            onChange={(e) => setEditBody(e.target.value)}
            onKeyDown={handleEditKeyDown}
            rows={3}
          />
          <div className="note-edit-actions">
            <button
              type="button"
              className="btn-secondary"
              onClick={handleCancelEdit}
              disabled={submitting}
            >
              <X size={14} />
              <span>{t('cancel')}</span>
            </button>
            <button
              type="button"
              className="btn-primary"
              onClick={handleEdit}
              disabled={!editTitle.trim() || !editBody.trim() || submitting}
            >
              <Check size={14} />
              <span>{submitting ? t('saving') : t('save')}</span>
            </button>
          </div>
          <span className="note-edit-hint">{t('editHint')}</span>
        </div>
      ) : (
        <>
          <div className="note-title">{note.title}</div>
          <div className="note-body">{note.body}</div>
        </>
      )}

      {note.replies && note.replies.length > 0 && (
        <div className="note-replies">
          {note.replies.map((reply) => (
            <div key={reply.id} className="note-reply">
              <div className="reply-header">
                <div className="reply-avatar">
                  {reply.user.initials}
                </div>
                <div className="reply-meta">
                  <span className="reply-author">{reply.user.fullName}</span>
                  <span className="reply-role">{reply.user.role}</span>
                  <span className="reply-date">{formatDateTime(reply.createdAt)}</span>
                </div>
              </div>
              <div className="reply-body">{reply.body}</div>
            </div>
          ))}
        </div>
      )}

      {isAdmin && (
        <div className="note-actions">
          {!showReplyInput ? (
            <button
              type="button"
              className="note-reply-toggle"
              onClick={() => setShowReplyInput(true)}
            >
              <MessageCircle size={15} />
              <span>{t('reply')}</span>
            </button>
          ) : (
            <div className="note-reply-input-wrapper">
              <input
                type="text"
                className="note-reply-input"
                placeholder={t('writeReply')}
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                onKeyDown={handleKeyDown}
                autoFocus
              />
              <button
                type="button"
                className="note-reply-send"
                onClick={handleReply}
                disabled={!replyText.trim() || submitting}
              >
                <Send size={15} />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
