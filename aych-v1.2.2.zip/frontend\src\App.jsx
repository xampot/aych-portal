import React from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.jsx';
import { LanguageProvider } from './context/LanguageContext.jsx';
import { LoginPage } from './pages/LoginPage.jsx';
import { ProjectsPage } from './pages/ProjectsPage.jsx';
import { DashboardPage } from './pages/DashboardPage.jsx';
import { LoadingSpinner } from './components/LoadingSpinner.jsx';

const AppContent = () => {
  const { isAuthenticated, selectedProject, loading } = useAuth();

  if (loading) {
    return (
      <div style={{ display: 'flex', height: '100vh', alignItems: 'center', justifyContent: 'center' }}>
        <LoadingSpinner />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  if (!selectedProject) {
    return <ProjectsPage />;
  }

  return <DashboardPage />;
};

export const App = () => {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LanguageProvider>
  );
};

export default App;
