import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Search, Bell, LogOut, BellOff, CheckCheck, FileUp, FileX, MessageSquare } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';
import { useNotifications } from '../hooks/useNotifications.js';
import { LanguageToggle } from './LanguageToggle.jsx';

const NOTIF_ICONS = {
  file_upload: FileUp,
  file_delete: FileX,
  note_create: MessageSquare,
  note_reply: MessageSquare,
  note_delete: MessageSquare
};

function formatNotifTime(dateStr, lang) {
  if (!dateStr) return '';
  const now = Date.now();
  const then = new Date(dateStr + 'Z').getTime();
  const diffMs = now - then;
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return lang === 'ar' ? 'الآن' : 'Just now';
  if (mins < 60) return lang === 'ar' ? `${mins}د` : `${mins}m`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return lang === 'ar' ? `${hrs}س` : `${hrs}h`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return lang === 'ar' ? `${days}ي` : `${days}d`;
  return new Date(dateStr + 'Z').toLocaleDateString(lang === 'ar' ? 'ar' : 'en');
}

export const Navbar = ({ search, onSearchChange }) => {
  const { user, company, logout, selectedProject } = useAuth();
  const { t, lang } = useLanguage();
  const [menuOpen, setMenuOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const notifRef = useRef(null);

  const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotifications(selectedProject?.id);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (notifRef.current && !notifRef.current.contains(e.target)) {
        setNotifOpen(false);
      }
    };
    const handleEscape = (e) => {
      if (e.key === 'Escape') setNotifOpen(false);
    };
    if (notifOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscape);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [notifOpen]);

  const initials = user?.initials || company?.code || 'WO';

  const handleNotifClick = async (notif) => {
    if (!notif.is_read) {
      await markAsRead(notif.id);
    }
  };

  return (
    <header className="portal-navbar">
      <div className="navbar-container">
        <div className="navbar-brand">
          <img src="/logo.png" alt="Aych Portal" className="navbar-logo" />
          <span className="navbar-title">{t('portalName')}</span>
        </div>

        <div className={`navbar-search-wrapper ${mobileSearchOpen ? 'mobile-search-visible' : ''}`}>
          <Search size={18} className="navbar-search-icon" />
          <input
            type="text"
            className="navbar-search-input"
            placeholder={t('searchPlaceholder')}
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            autoFocus={mobileSearchOpen}
          />
          {mobileSearchOpen && (
            <button
              type="button"
              className="navbar-search-close"
              onClick={() => { setMobileSearchOpen(false); onSearchChange(''); }}
              aria-label="Close search"
            >
              ✕
            </button>
          )}
        </div>

        <div className="navbar-actions">
          <button
            type="button"
            className="navbar-search-mobile-toggle"
            onClick={() => setMobileSearchOpen((prev) => !prev)}
            aria-label="Search"
          >
            <Search size={19} />
          </button>

          <LanguageToggle className="navbar-lang-toggle" />

          <div className="navbar-notif-wrapper" ref={notifRef}>
            <button
              type="button"
              className="navbar-icon-btn"
              aria-label="Notifications"
              onClick={() => setNotifOpen((prev) => !prev)}
            >
              <Bell size={19} />
              {unreadCount > 0 && (
                <span className="notif-badge">{unreadCount > 99 ? '99+' : unreadCount}</span>
              )}
            </button>

            {notifOpen && (
              <div className="navbar-dropdown notif-dropdown">
                <div className="notif-dropdown-header">
                  <span className="notif-dropdown-title">{t('notifications')}</span>
                  {unreadCount > 0 && (
                    <button
                      type="button"
                      className="notif-mark-all-btn"
                      onClick={markAllAsRead}
                    >
                      <CheckCheck size={14} />
                      <span>{t('markAllRead')}</span>
                    </button>
                  )}
                </div>
                {notifications.length === 0 ? (
                  <div className="notif-empty">
                    <BellOff size={20} />
                    <span>{t('noNotifications')}</span>
                  </div>
                ) : (
                  <div className="notif-list">
                    {notifications.map((notif) => {
                      const Icon = NOTIF_ICONS[notif.type] || Bell;
                      return (
                        <button
                          key={notif.id}
                          type="button"
                          className={`notif-item ${notif.is_read ? '' : 'notif-unread'}`}
                          onClick={() => handleNotifClick(notif)}
                        >
                          <div className={`notif-icon-wrap notif-icon-${notif.type}`}>
                            <Icon size={14} />
                          </div>
                          <div className="notif-content">
                            <span className="notif-message">{notif.message}</span>
                            <span className="notif-time">{formatNotifTime(notif.created_at, lang)}</span>
                          </div>
                          {!notif.is_read && <span className="notif-dot" />}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="navbar-user-wrapper">
            <button
              type="button"
              className="navbar-avatar-btn"
              onClick={() => setMenuOpen((prev) => !prev)}
              aria-label="User profile"
            >
              {initials}
            </button>

            {menuOpen && (
              <div className="navbar-dropdown">
                <div className="dropdown-user-info">
                  <span className="dropdown-user-name">{user?.fullName || company?.name}</span>
                  <span className="dropdown-user-role">{user?.role || 'Admin'}</span>
                </div>
                <button
                  type="button"
                  className="dropdown-logout-btn"
                  onClick={() => {
                    setMenuOpen(false);
                    logout();
                  }}
                >
                  <LogOut size={16} />
                  <span>{t('loggedOut')}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
