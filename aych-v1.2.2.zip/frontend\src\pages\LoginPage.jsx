import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';
import { LanguageToggle } from '../components/LanguageToggle.jsx';

export const LoginPage = () => {
  const { login } = useAuth();
  const { t, isRtl } = useLanguage();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [statusKey, setStatusKey] = useState('loggedOut');
  const [errorText, setErrorText] = useState(null);
  const [isError, setIsError] = useState(false);

  const displayMessage = errorText || t(statusKey);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!username.trim() || !password) return;

    setSubmitting(true);
    setIsError(false);
    setErrorText(null);

    try {
      await login(username.trim(), password);
    } catch (err) {
      setIsError(true);
      if (err.message) {
        setErrorText(err.message);
      } else {
        setStatusKey('invalidCredentials');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-lang-wrapper">
        <LanguageToggle className="login-lang-btn" />
      </div>

      <div className="login-card-wrapper">
        <div className="login-card">
          <div className="login-card-inner">
            <div className="login-logo-section">
              <div className="login-logo-circle">
                <img src="/logo.png" alt="Aych Portal Logo" className="login-emblem" />
              </div>
            </div>

            <div className="login-form-section">
              <form onSubmit={handleSubmit} className="login-form">
                <div className="form-group">
                  <input
                    type="text"
                    id="username"
                    name="username"
                    className="login-input"
                    placeholder={t('username')}
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    autoComplete="username"
                  />
                </div>

                <div className="form-group">
                  <input
                    type="password"
                    id="password"
                    name="password"
                    className="login-input"
                    placeholder={t('password')}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    autoComplete="current-password"
                  />
                </div>

                <button
                  type="submit"
                  className="login-submit-btn"
                  disabled={submitting}
                >
                  {submitting ? t('signingIn') : t('signIn')}
                </button>

                <div className={`login-status-text ${isError ? 'login-status-error' : ''}`}>
                  {displayMessage}
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
