import React, { useState } from 'react';
import { Search, Bell, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';
import { LanguageToggle } from './LanguageToggle.jsx';

export const Navbar = ({ search, onSearchChange }) => {
  const { user, company, logout } = useAuth();
  const { t } = useLanguage();
  const [menuOpen, setMenuOpen] = useState(false);

  const initials = user?.initials || company?.code || 'WO';

  return (
    <header className="portal-navbar">
      <div className="navbar-container">
        <div className="navbar-brand">
          <img src="/logo.png" alt="Aych Portal" className="navbar-logo" />
          <span className="navbar-title">{t('portalName')}</span>
        </div>

        <div className="navbar-search-wrapper">
          <Search size={18} className="navbar-search-icon" />
          <input
            type="text"
            className="navbar-search-input"
            placeholder={t('searchPlaceholder')}
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
          />
        </div>

        <div className="navbar-actions">
          <LanguageToggle className="navbar-lang-toggle" />

          <button type="button" className="navbar-icon-btn" aria-label="Notifications">
            <Bell size={19} />
          </button>

          <div className="navbar-user-wrapper">
            <button
              type="button"
              className="navbar-avatar-btn"
              onClick={() => setMenuOpen((prev) => !prev)}
              aria-label="User profile"
            >
              {initials}
            </button>

            {menuOpen && (
              <div className="navbar-dropdown">
                <div className="dropdown-user-info">
                  <span className="dropdown-user-name">{user?.fullName || company?.name}</span>
                  <span className="dropdown-user-role">{user?.role || 'Admin'}</span>
                </div>
                <button
                  type="button"
                  className="dropdown-logout-btn"
                  onClick={() => {
                    setMenuOpen(false);
                    logout();
                  }}
                >
                  <LogOut size={16} />
                  <span>{t('loggedOut')}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
