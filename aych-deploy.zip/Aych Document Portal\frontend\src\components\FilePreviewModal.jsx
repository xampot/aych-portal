import React, { useEffect, useState } from 'react';
import { X, Download, FileText, Image as ImageIcon, StickyNote, CheckCircle2, File } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.jsx';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';

export const FilePreviewModal = ({ file, onClose, onDownload }) => {
  const { t } = useLanguage();
  const { token } = useAuth();
  const [details, setDetails] = useState(null);
  const [loading, setLoading] = useState(true);

  const getCategoryIcon = (category) => {
    const cat = (category || '').toLowerCase();
    if (cat.includes('document') || cat.includes('contract') || cat.includes('report') || cat.includes('عقود') || cat.includes('تقارير') || cat.includes('مستندات')) {
      return <FileText size={32} />;
    }
    if (cat.includes('gallery') || cat.includes('image') || cat.includes('صور') || cat.includes('معرض')) {
      return <ImageIcon size={32} />;
    }
    if (cat.includes('note') || cat.includes('invoice') || cat.includes('ملاحظات') || cat.includes('فواتير')) {
      return <StickyNote size={32} />;
    }
    return <FileText size={32} />;
  };

  useEffect(() => {
    let isMounted = true;
    const loadDetails = async () => {
      try {
        const data = await api.getFilePreview(file.id, token);
        if (isMounted) setDetails(data);
      } catch (err) {
        if (isMounted) setDetails(file);
      } finally {
        if (isMounted) setLoading(false);
      }
    };
    loadDetails();
    return () => {
      isMounted = false;
    };
  }, [file, token]);

  const isImage = (file.mimeType || file.mime_type || '').startsWith('image/');
  const isPdf = (file.mimeType || file.mime_type || '') === 'application/pdf';
  const isText = (file.mimeType || file.mime_type || '').startsWith('text/');
  const fileUrl = file.fileUrl || file.file_url;
  const hasActualFile = fileUrl && fileUrl.startsWith('/uploads/');

  const renderPreview = () => {
    if (!hasActualFile) {
      return (
        <div className="preview-not-available">
          <File size={48} />
          <p>{t('previewNotAvailable')}</p>
          <p className="preview-hint">{t('downloadToView')}</p>
        </div>
      );
    }

    if (isImage) {
      return (
        <div className="preview-image-wrapper">
          <img src={fileUrl} alt={file.name} className="preview-image" />
        </div>
      );
    }

    if (isPdf) {
      return (
        <div className="preview-pdf-wrapper">
          <iframe src={fileUrl} className="preview-pdf" title={file.name} />
        </div>
      );
    }

    if (isText) {
      return <TextPreview url={fileUrl} />;
    }

    return (
      <div className="preview-not-available">
        <File size={48} />
        <p>{t('previewNotSupported')}</p>
        <p className="preview-hint">{t('downloadToView')}</p>
      </div>
    );
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container modal-preview" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div className="modal-title-box">
            <FileText size={20} className="modal-icon" />
            <h3 className="modal-title">{t('documentPreview')}</h3>
          </div>
          <button type="button" className="modal-close-btn" onClick={onClose} aria-label="Close">
            <X size={20} />
          </button>
        </div>

        <div className="modal-body">
          <div className="modal-file-banner">
            <div className="modal-file-icon">
              {getCategoryIcon(file.category)}
            </div>
            <div className="modal-file-meta">
              <h4 className="modal-file-name">{file.name}</h4>
              <span className="modal-file-category">{file.category}</span>
            </div>
          </div>

          <div className="modal-info-grid">
            <div className="modal-info-item">
              <span className="info-label">{t('size')}</span>
              <span className="info-value">{file.formattedSize || file.formatted_size}</span>
            </div>
            <div className="modal-info-item">
              <span className="info-label">{t('date')}</span>
              <span className="info-value">{file.createdAt ? file.createdAt.split(' ')[0] : '-'}</span>
            </div>
            <div className="modal-info-item">
              <span className="info-label">{t('category')}</span>
              <span className="info-value">{file.category}</span>
            </div>
            <div className="modal-info-item">
              <span className="info-label">{t('companyVerification')}</span>
              <span className="info-value modal-verified">
                <CheckCircle2 size={15} />
                <span>{details?.company || 'Verified'}</span>
              </span>
            </div>
          </div>

          <div className="preview-section">
            {renderPreview()}
          </div>
        </div>

        <div className="modal-footer">
          <button type="button" className="btn-secondary" onClick={onClose}>
            {t('close')}
          </button>
          <button
            type="button"
            className="btn-primary modal-download-btn"
            onClick={() => onDownload(file)}
          >
            <Download size={16} />
            <span>{t('downloadDocument')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

function TextPreview({ url }) {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    let isMounted = true;
    fetch(url)
      .then((res) => {
        if (!res.ok) throw new Error('Failed to load');
        return res.text();
      })
      .then((text) => {
        if (isMounted) setContent(text);
      })
      .catch(() => {
        if (isMounted) setError(true);
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });
    return () => { isMounted = false; };
  }, [url]);

  if (loading) return <div className="preview-loading">Loading...</div>;
  if (error) return <div className="preview-not-available"><File size={48} /><p>Failed to load preview</p></div>;

  return (
    <div className="preview-text-wrapper">
      <pre className="preview-text-content">{content}</pre>
    </div>
  );
}
